﻿namespace WeddingInvitation.Models
{
	//Programmer :Luvo Tsholoba
	//Date:12/26/2024
	//Purpose: The purpose of this program is to show case my basic understanding of MVC and show case how C# and blend in with HTML
	//Website: This website is a basic website that invites individuals can be friends or family and they have to fill the form and after they will be able to see who is also attending the wedding.
	//Used: I created a repository to save the responses i got from the individuals
	//    :I used validation so that the users can completely fill the form.
	//    :I used bootstrap to make my website more appealing    


	public static  class Repo
    {
        //Method purpose: To save the users responses
        private static List<Guests> responses = new List<Guests>();
        public static IEnumerable<Guests> Responses
        {
            get { return responses; }
        }
        public static void AddResponses(Guests response)
        {
            responses.Add(response);
        }
    }
}

﻿using System.ComponentModel.DataAnnotations;

//Programmer :Luvo Tsholoba
//Date:12/26/2024
//Purpose: The purpose of this program is to show case my basic understanding of MVC and show case how C# and blend in with HTML
//Website: This website is a basic website that invites individuals can be friends or family and they have to fill the form and after they will be able to see who is also attending the wedding.
//Used: I created a repository to save the responses i got from the individuals
//    :I used validation so that the users can completely fill the form.
//    :I used bootstrap to make my website more appealing

namespace WeddingInvitation.Models
{
	public class Guests
	{
		[Required (ErrorMessage ="Please enter your Name")]

		public string Name { get; set; }

		[Required(ErrorMessage = "Please enter your Surname")]
		public string Surname { get; set; }

		[Required(ErrorMessage = "Please choose")]
		public bool? Answer { get; set; }

		[Required(ErrorMessage = "Please enter number of plus one's")]
		
		public int plusOne { get; set; }

	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo TSHOLOBA
//DATE:31 MARCH 2022
//THIS PROGRAM GIVES A DISCOUNT TO THE USER IF THE USER IS OLDER 65 AND A FAMALE

namespace NestediF
{
    internal class Program
    {
        static string userName, userGender;
        static int userAge;

        static void Main(string[] args)
        {
            HouseKeeping();
            Details();
            EndofProgram();
        }
        static void HouseKeeping()
        {
            //uasking for users name
            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName = Console.ReadLine();
            //asking for users gender
            Console.WriteLine("PLEASE ENTER YOUR GENDER.FEMALE OR MALE.");
            userName = Console.ReadLine();
            //asking for users age
            Console.WriteLine("PLEASE ENTER YOUR AGE");
            userAge = Convert.ToInt32(Console.ReadLine());

        }
        static void Details()
        {
            if (userAge > 64)
            {
                Console.WriteLine("YOU QUALIFY FOR A DISCOUNT");
                if (userGender == "FEMALE") ;

            }
            else
            {
                Console.WriteLine("SORRY ,YOU DONT QUALIFY FOR A DISCOUNT");
            }
                    
        }
        static void EndofProgram()
        {
            Console.WriteLine("PRESS ANY KEY TO EXIT THE PROGRAM");
            Console.ReadKey();
                

        }
    }
}

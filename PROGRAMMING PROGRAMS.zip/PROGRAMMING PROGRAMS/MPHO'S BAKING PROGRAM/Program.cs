﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:08 APRIL 2022

namespace MPHO_S_BAKING_PROGRAM
{
    internal class Program
    {
        //global variables
        static string userName;
            static double eggsAMOUNT, bakingPOWDER, butter, flour, milk, vanilla, sugar;
        static double userInput, totalCakes, numberOfCakes;
        //Constant vaiavbles
        const double EGGSAMOUNT = 2, BAKINGPOWDERTEASPOON = 1.27, BUTTERCUPS = 0.5, FLOURCUPS = 1.5, MILKCUPS = 0.5, VANILLATEASPOON = 2, SUGARCUPS = 1;

        static void Main(string[] args)
        {
            StartScreen();
            MainMenu();
            EndOfProgram();
        }
        static void StartScreen()
        {
            Console.WriteLine("--------------------------------------------------------------------");
            Console.WriteLine("MPHO'S CAKE INGREDIENTS CALCULATOR");
            Console.WriteLine();
            //this program calculate how much ingredients you need to bake cakes.
            Console.WriteLine();
            Console.WriteLine("      INGREDIENTS FOR 1 CAKE  ");
            Console.WriteLine("ITEM             MEASUREMENTS                    QTY");
            Console.WriteLine("----              ----------                      -----");
            Console.WriteLine("eggs            AMOUNT                           2");
            Console.WriteLine("BAKING POWDER       TEASPOON                          1.27");
            Console.WriteLine("BUTTER              CUPS                              0.5");
            Console.WriteLine("FLOUR               CUPS                              1.5");
            Console.WriteLine("MILK                CUPS                              0.5");
            Console.WriteLine("VANILLA             TEASPOOON                         2");
            Console.WriteLine("SUGAR               CUPS                              1");
            Console.WriteLine("--------------------------------------------------------------------");
            Console.ReadKey();

        }
        static void MainMenu()
        {
            //ASKING FOR THE USER INPUT 
            Console.Clear();
            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("THANK YOU {0}.PLEASE ENTER HOW MANY CAKES YOU WANT TO BAKE ?", userName);
            userInput = Convert.ToDouble(Console.ReadLine());
            //GOING TO DO THE CALCULATINS
            totalCakes = userInput * EGGSAMOUNT * BAKINGPOWDERTEASPOON * BUTTERCUPS * FLOURCUPS * MILKCUPS * VANILLATEASPOON * SUGARCUPS;
            numberOfCakes = totalCakes * eggsAMOUNT*bakingPOWDER*butter*flour* milk*vanilla*sugar;



        }
        static void EndOfProgram()
        {
            Console.Clear();
            Console.WriteLine("--------------------------------------------------------------------");
            Console.WriteLine("MPHO'S CAKE INGREDIENTS CALCULATOR");
            Console.WriteLine();
            //this program calculate how much ingredients you need to bake cakes.
            Console.WriteLine();
            Console.WriteLine("      INGREDIENTS FOR 1 CAKE  ");
            Console.WriteLine("ITEM             MEASUREMENTS                    QTY");
            Console.WriteLine("----              ----------                      -----");
            Console.WriteLine("EGGS                 AMOUNT                           {0}", eggsAMOUNT);
            Console.WriteLine("BAKING POWDER       TEASPOON                          {0}", bakingPOWDER);
            Console.WriteLine("BUTTER              CUPS                              {0}", butter);
            Console.WriteLine("FLOUR               CUPS                              {0}", flour);
            Console.WriteLine("MILK                CUPS                              {0}", milk);
            Console.WriteLine("VANILLA             TEASPOOON                         {0}", vanilla);
            Console.WriteLine("SUGAR               CUPS                              {0}", sugar);
            Console.WriteLine();
            Console.WriteLine("THE TOTAL CAKES YOU WANT TO BAKE IS:{0}", totalCakes);
            Console.WriteLine("--------------------------------------------------------------------");
            Console.ReadKey();



        }
    }    }
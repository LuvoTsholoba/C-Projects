﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main()
        {
            //Local variable
            int DAY;
            Console.Clear();
            Console.WriteLine("choosea a number between 1 amd 3 ,to show which day you chose");
            DAY = Convert.ToInt16(Console.ReadLine());

            switch(DAY)
            {
                case 1:
                    Console.WriteLine("MONDAY");
                    break;
                case 2:
                    Console.WriteLine("TUESDAY");
                    break;
                case 3:
                    Console.WriteLine("WEDNESDAY");
                    break;
                default:
                    Console.WriteLine("Invalid number");
                    break;
            }
            Console.ReadKey();
        }
    }
}

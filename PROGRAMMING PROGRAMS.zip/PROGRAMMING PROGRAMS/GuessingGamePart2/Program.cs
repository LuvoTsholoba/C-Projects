﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Programmer:Luvo Tsholoba
//Date:25 March 2022
//This Program is about the user guessing words and numbers


namespace GuessingGamePart2
{
    internal class Program

    {
        //Global variables 
        static string userWord;
       static int userNumber;
        //Global Constant Variables
        const string CORRECTWORD = "eyes";
        const int CORRECTNUMBER = 12;

        static void Main(string[] args)
        {
            StartScreen();
            MainMenu();
            NumberGame();
            WordGame();
            EndofProgram();
        }
        static void StartScreen()
        {
            Console.WriteLine("====================================================");
            Console.WriteLine(  "WELCOME TO WORDS AND NUMBERS GAME !!!!ENJOY ");
            Console.WriteLine();
            Console.WriteLine("====================================================");
            Console.WriteLine("PRESS ANY KEY TO PROCEED TO THE MAIN MENU");
            Console.ReadLine();
            Console.ReadKey();
        }
        static void MainMenu()
        {
            //Clearing of the screen
            Console.Clear();
            Console.WriteLine("====================================================");
            Console.WriteLine("WELCOME TO OUR MAIN MENU OF THE GAME.....");
            Console.WriteLine();
            Console.WriteLine("1.FOR NUMBERGAME.");
            Console.WriteLine("2.FOR WORDGAME.");
           Console.WriteLine("3.FOR EXIT THE GAME.");
            Console.WriteLine("====================================================");
            Console.WriteLine();

            //giving the instructions to the user.
            Console.WriteLine("PLEASE ENTER 1,2,3 TO THROUGH ...");
            userNumber = Convert.ToInt16(Console.ReadLine());

            //The user decisions 
            if (userNumber > 0 && userNumber < 4)
            {
                if (userNumber == 1)
                {
                    //GIVING THE PROGRAM INSTRUCTIONS 
                }
                {
                    NumberGame();
                }
                if (userNumber == 2)
                {
                    WordGame();

                }

                {
                    WordGame();
                }
                if (userNumber == 3)
                {
                    //call out the method
                    EndofProgram();

                }
                {
                    EndofProgram();
                }
            
                    
            }
            else
            {
                Console.WriteLine("YOU HAVE ENTERED THE INCORRECT NUMBER..PLEASE TRY AGAIN");
                Console.ReadLine();
                MainMenu();
                Console.ReadKey();
            }

        }
        static void NumberGame()
        {
            //CLEARING THE SCREEN
            Console.Clear();
            Console.WriteLine("====================================================");
            Console.WriteLine("WELCOME TO OUR NUMBER GAME.PLEASE ENJOY!!!!!!");
            Console.WriteLine();
            Console.WriteLine("====================================================");
            Console.WriteLine();
            Console.WriteLine("PLEASE GUESS THE CORRECT NUMBER FROM 9 TO 20");
            userNumber = Convert.ToInt32(Console.ReadLine());
        }
   

        static void WordGame()
        {
            //CLEARING THE SCREEN
            Console.Clear();
            Console.WriteLine("====================================================");
            Console.WriteLine("WELCOME TO OUR NUMBER GAME.PLEASE ENJOY!!!!!!");
            Console.WriteLine();
            Console.WriteLine("====================================================");
            Console.WriteLine();
            Console.WriteLine("PLEASE GUESS THE CORRECT WORD THAT ALLOWS HUMANS AND ANIMALS TO KNOW WHAT THEY ARE LOOKING FOR.");
            Console.ReadLine();
        }
            


        static void EndofProgram()
        {
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 

//Programmer:Luvo Tsholoba
//Date:18 march 2022
//PROGRAMS IS ABOUT LERATO'S ONLIME SHOP

namespace ScenarioProgram
{
    internal class Program
    {
        static void Main()
        {//Local variable
            string name;
            string profit;
            int order; ;
            int pirce;


            //WELCOMING SCREEN
            Console.WriteLine("  LERATO'S ONLINE MILK SHOP ");
            Console.WriteLine();
            Console.WriteLine("PRICE PER LITER OF MILK IS R12.99");
            Console.WriteLine();

            //ClientsInPUT
            Console.WriteLine();
            Console.WriteLine("WELCOME TO OUR SHOP.PLEASE ENTER YOUR NAME");
            name = Console.ReadLine();
            Console.ReadLine();
            Console.WriteLine("Thank you.{0} we received your details", name);
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER HOW MUCH MILK YOU WOULD LIKE TO ORDER");
            order = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("THANK YOU.{0} ORDER HAS BEEN PLACED", name);
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO PRINT INVOICE");
            Console.ReadKey();
            Console.WriteLine("******************************************************************");
            Console.WriteLine("                   TAX INVOICE      ");
            Console.WriteLine("CLIENT NAME:{0}", name);
            Console.WriteLine("Litre of milk ordered:{0}", order);
            Console.WriteLine("PRESS ANY KEY TO MAKE A PAYMENTS");
            Console.ReadKey();
                 

        }

    }
}

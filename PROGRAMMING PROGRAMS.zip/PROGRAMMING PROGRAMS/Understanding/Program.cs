﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo tsholoba
//Date:15 March 2022
//Just basic progra non major


namespace Understanding
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Local variable
            String name, surname;
            int age;
            int salary;
            //Provides the users name
            Console.WriteLine("Please enter your name");
            name=Console.ReadLine();
            //Provides users surname
            Console.WriteLine("Please enter your surname");
          Console.ReadLine();
            //Provides users age
            Console.WriteLine("Please enter your age");
            age = Convert.ToInt32(Console.ReadLine());
            //Users salary
            Console.WriteLine("Please enter your salary");
            salary = Convert.ToInt32(Console.ReadLine());

            //USERS INFORMATION IN FULL
            Console.WriteLine();
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("User name:    {0} ",name);
            Console.WriteLine("user surname: {0}" surname);
            Console.WriteLine("user age:   {0}",age);
            Console.WriteLine("user salary: {0}",salary);
            Console.WriteLine("----------------------------------------------");
            Console.ReadKey();






        }
    }
}

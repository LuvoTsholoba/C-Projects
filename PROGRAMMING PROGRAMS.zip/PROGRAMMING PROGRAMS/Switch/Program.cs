﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch
{
    internal class Program
    {
        //Global variabls
        static int monthNumber;

        static void Main(string[] args)
        {
            //calling methods
            HouseKeeping();
            Details();
            EndofProgram();
        }
        static void HouseKeeping()
        {
            //getting a number from 1-12
            Console.WriteLine("PLEASE ENTER THE NUMBER FORM 1-12");
            monthNumber = Convert.ToInt32(Console.ReadLine());
        }
        static void Details()
        {
            switch (monthNumber)
            {
                case 1:
                    Console.WriteLine("THE MONTH IS JANUARY");
                    break;
                case 2:
                    Console.WriteLine("THE MONTH IS FEBRUARY");
                    break;
                default:
                    Console.WriteLine("THE NUMBER YOU ENTERED IS INVALID!!!!");
                    break;
                    
            }

        }
        static void EndofProgram()
        {
            Console.WriteLine("THANKS.PRESS ANY KEY TO EXIT THE PROGRAMME");
            Console.ReadKey();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramminUsingIf
{
    internal class Program
    {
        //Global variables
        static string userName;
         static int userAGE;

        static void Main(string[] args)
        {
            HouseKeeping();
            Details();
        }
         static void HouseKeeping()
         {
            Console.WriteLine("DISCOUNT FOR PENSIONERS");
            Console.WriteLine();
            //getting userName from the user:
            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName = Console.ReadLine();
            //Users age
            Console.WriteLine("PLEASE ENETER YOUR AGE:");
            userAGE=Convert.ToInt16(Console.ReadLine());
         }
        static void Details()
        {
            if (userAGE > 64)
            {
                //IF THE CONDITION IS TRUE
                Console.WriteLine("YOU GUALIFY FOR PENSIONERS DISCOUNT");
                Console.ReadLine();
            }
            else
            {
                //iF THE CONDITION IS FALSE 
                Console.WriteLine("YOU DO NOT GUALIFY FOR PENSIONERS DISCOUNT.SORRY");

            }

             


          }
    }
}

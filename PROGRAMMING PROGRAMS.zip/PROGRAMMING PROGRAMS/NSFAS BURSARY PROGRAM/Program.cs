﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:044 May 2022

namespace NSFAS_BURSARY_PROGRAM
{
    internal class Program
    {
        //Globa variables
        static string userName, userSurname,Dob;
        static double idNo, contactNo;
        static void Main()
        {
            startScreen();
        }
        static void startScreen()
        {
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("*NSFAS BURSARY ONLINE APPLICATION    *");
            Console.WriteLine("*                                    *  " );
            Console.WriteLine("*  APPLY NOW !!!                     *");
            Console.WriteLine("-------------------------------------");
            Console.ReadKey();
            Menu();
        }
        static void Menu()
        {
            Console.Clear();
            Console.Clear();
            Console.WriteLine("PLEASE ENTER YOUR NAME");
            userName= Console.ReadLine();
            Console.WriteLine("PLease enter your Surname:");
            userSurname = Console.ReadLine();
            Console.WriteLine("PLease enter the date of your birth:");
            Dob = (Console.ReadLine());
            Console.WriteLine("Please enter your ID number");
            idNo = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("PLease enter your contact number");
            contactNo = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Thank you Mr {0} we have received all of your information.Press any key to review", userSurname);
            Console.ReadKey();
            Report();

        }
        static void Report()
        {
            Console.Clear();
            Console.WriteLine("SUMMARY OF THE GIVEN INFORMATION");
            Console.WriteLine();
            Console.WriteLine("NAME:{0}"
                ,userName);
            Console.WriteLine("Surname:{0}",
                userSurname);
            Console.WriteLine("Date of birth:{0}",
                Dob);
            Console.WriteLine("ID NUMBER:{0}",
                idNo);
            Console.WriteLine("Contact number:",
                contactNo);
            Console.WriteLine();
            Console.WriteLine("Press any key to submit your applicaton.Thank you !!");
            Console.ReadKey();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Programmer:Luvo Tsholoba
//Date:24 march 2022
//This program is about guessing right both in word and numbers game
//Sydent number:222000756

namespace Guessin


    internal class Program
    //Globa Variables 
    {
        static int userNumber;
        static string userWord;
        static string Menu;
        //Constant Variabales
        const int CORRECTNUMBER = 12;
        const string COREECTWORD = " HOT DOG";

        static void StartScreen()
        {
            //WELCOMING THE GAMER
            Console.WriteLine("======================================================================");
            Console.WriteLine("          HELLO ! WELCOME TO OUR GAME OF WORD AND NUMBER.");
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO START THE GAME              ");
            Console.WriteLine("======================================================================");
            Console.ReadKey();

        }
        static void MainMenu()
        {
            //Clearing of the screen
            Console.Clear();
            //GIVING THE USER OPTIONS
            Console.WriteLine("======================================================================");
            Console.WriteLine("MAIN MENU OF OUR GAME ");
            Console.WriteLine();
            Console.WriteLine("1.FOR WORD GAME  ");
            Console.WriteLine("2.FOR NUMBER GAME");
            Console.WriteLine("3.FOR EXTITING");
            Console.WriteLine("======================================================================");

            Console.WriteLine("PLEASE ENTER 1,2 OR 3 FOR MENU OPTIONS");
            Convert.ToInt16(Console.ReadLine());
            Console.WriteLine();

            //Checking the user input about choosing a game



        }
        static void NumberGame()
        {
            Console.WriteLine("===================================");
            Console.WriteLine("WELCOME TO THE NUMBER GAME! PLEASE ENJOY");
            Console.WriteLine();
            Console.WriteLine("===================================");


            Console.WriteLine("PLEASE GUEES THE NUMBER BETWEEN 12 AND 20:");
            userNumber = Convert.ToInt32(Console.ReadLine());

            //Checking if the user guessed right
            if (userNumber == CORRECTNUMBER)
            {
                //congratulate the user
                Console.WriteLine("YOU GUESSED THE CORRECT WORD!!!!!!CONGRATULATIONS.***");
                Console.WriteLine("PRESS ANY KEY TO CONTINUE");
                Console.ReadKey();
                Console.WriteLine();
                MainMenu();
            }
            else
            {
                Console.WriteLine("SORRY!! YOU HAVE ENTER THE INCORRECT WORD!");
                Console.WriteLine("");
                Console.WriteLine("PRESS ANY KEY TO CONTINUE...");
                Console.WriteLine("");
                MainMenu();

            }

        }
    }        static void WordGame()
        {
            Console.WriteLine("===================================");
            Console.WriteLine("WELCOME TO THE WordGame! PLEASE ENJOY");
            Console.WriteLine();
            Console.WriteLine("===================================");


            Console.WriteLine("PLEASE GUEES THE CORRECT WORD THAT IS USED MAINLY FOR TAKE AWAYS:");
            Console.ReadLine();

            //Checking if the user guessed right
            if (userWord == COREECTWORD)
            {

                //congratulate the user
                Console.WriteLine("YOU GUESSED THE CORRECT WORD!!!!!!CONGRATULATIONS.***");
                Console.WriteLine("PRESS ANY KEY TO CONTINUE");
                Console.WriteLine();
                MainMenu();
                Console.ReadKey();

            }
            else }

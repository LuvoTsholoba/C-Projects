﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsfasProgram
{
    internal class Program
    {
        //Global variables 
        static string userName, userSurname, dateofBirth;
        static Double IdNo, ConNO;

        static void Main(string[] args)
        {
            StartSctreen();
            Menu();
            Print();
            EndofProgram();
        }
        static void StartSctreen()
        {
            Console.WriteLine("NSFAS BURSARY ONLINE APPLICATION");
            Console.WriteLine();
            Console.WriteLine("APPLY NOW");
            Console.ReadKey();
        }
        static void Menu()
        {

            Console.WriteLine("ENTER YOUR NAME");
            userName = Console.ReadLine();
            Console.WriteLine("ENTER SURNAME");
            userSurname = Console.ReadLine();
            Console.WriteLine("ENTER DATE OF BIRTH");
            dateofBirth = Console.ReadLine();
            Console.WriteLine("ENTER ID NUMBER");
            IdNo = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("ENTER CONTACT NUMBER");
            ConNO = Convert.ToDouble(Console.ReadLine());
            Console.ReadKey();
            Print();

        }
        static void Print()
        {
            //Clearing out the screen
          
            Console.WriteLine("YOUR NAME:{0}", userName);
            Console.WriteLine("SURNAME:{0}", userSurname);
            Console.WriteLine("date of birth:{0}", dateofBirth);
            Console.WriteLine("Id number:{0}", IdNo);
            Console.WriteLine("Contact Number:{0}", ConNO);
            Console.ReadKey();
            EndofProgram();

        }
        static void EndofProgram()
        {

            Console.WriteLine("THANK YOU FOR USING OUR SYSTEM.PRESS ANY KEY TO EXIT");
            Console.ReadKey();

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:3 May 2022

namespace BLOEMFONTEIN_TILE_STORE_PROGRAM
{
    internal class Program
    {
        //Global variables
        static string userName;
        //Constatnnt variables 
        const double COST = 104;
        static Double area, totalCost, Length, width;
        static void Main()
        {
            Calculations();
            Menu();
            inputs();
            printInvoice();
        }
        static void Menu()
        {
            Console.BackgroundColor = ConsoleColor.Green;
            //THE STARTUP SCREEN
            Console.WriteLine("BLOEM TILES STORE - ONLINE.");
            Console.WriteLine();
            Console.WriteLine("FOR TODAY ONLY!!! R104 SQUARE METER ON MARBLE TILE.");
            Console.WriteLine("");
            Console.WriteLine("FOLLOW THE NEXT STEP FOR ORDER");
            Console.ReadLine();

        }
        static void inputs()
        {
            //GETTING INPUTS FROM THE USER
            Console.WriteLine("Welcome to our online store.Please enter your Name.");
            userName = Console.ReadLine();
            Console.WriteLine("Thank you {0},Now we will process your order for Marble tiles.", userName);
            Console.WriteLine();
            Console.WriteLine("PLease enter your Lenght in meters,of the room you want to tile");
            Length = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Thank you length accepted");
            Console.WriteLine();
            Console.WriteLine("PLease enter your width in meters,Of the room you want to tile");
            width = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Thank you width accepted");
            Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("WE WILL NOW CALCULATE YOUR COST.PLEASE WAIT");
            Console.WriteLine();
            Console.WriteLine("PRESS ENY KEY TO GET YOUR TAX INVOICE");
            Console.ReadKey();

        }
        static void Calculations()
        {
            totalCost = Length * width * COST;
            Console.ReadKey();

        }
        static void printInvoice()
        {
            Console.Clear();
            //Printing the output 
            Console.WriteLine("BLOEM TILES STORE - ONLINE.");
            Console.WriteLine("    TAX INVOICE");
            Console.WriteLine();
            Console.WriteLine("ITEM                  PRICE                       QTY-sqM");
            Console.WriteLine("MARBLE                R104.00                      {0}", area);
            Console.WriteLine();
            Console.WriteLine("TOTAL DUE R{0}", totalCost);
            Console.WriteLine();
            Console.WriteLine("      THANK YOU FOR SUPPORTING OUR STORE");
            Console.WriteLine();
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.WriteLine("PRESS ANY KEY TO ACCEPT INSTANT PAYMENT AND EXIT ONINE ORDERS");
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba

namespace Voucheer_PROGRAM
{
    internal class Program
        //Global Variables
    {
        static string userName, userSurname, userEmployment;
        static int userNumber,userAGe;
        static bool employment;
        static void Main()
        {
            //Calling methods
            Menu();
            GetData();
            ConfirmData();
            DiscountCheck();
            ExitProgram();
        }
        static void Menu()
        {
            //Clearing the screen
            Console.Clear();
            Console.WriteLine("VOUCHER FOR THE USER: MAIN MENU");
            Console.WriteLine();
            Console.WriteLine("1.CAPTURE YOUR INFORMATION");
            Console.WriteLine("2.CONFIRM YOUR INFORMATION");
            Console.WriteLine("3.PRINT VOUCHER FOR THE USER");
            Console.WriteLine("4.EXIT THE SYSTEM");
            Console.WriteLine();
            Console.WriteLine("PLEASE PRESS 1,2,3 AND 4 TO ENTER THAT SYSTEM....");
            userNumber = Convert.ToInt16(Console.ReadLine());

            //CHECKIBG THE CORRECT NUMBER FROM THE USER
            switch (userNumber)
            {
                case 1:
                    GetData();
                    break;
                case 2:
                    ConfirmData();
                    break;
                case 3:
                    DiscountCheck();
                    break;
                case 4:
                    ExitProgram();
                    break;
              
                default:
                    Console.WriteLine("YOU HAVE ENTERED THE INVALID NUMBER.PLEASE TRY AGAIN..");
                    Console.WriteLine("PRESS ANY KEY TO TRY AGAIN.");
                    Console.ReadKey();
                    Menu();
                    break;

            }


        }
        static void GetData()
        {
            //cLEAR THE SCREEN
            Console.Clear();
            //GETTING THE USER INFORMATION....
            Console.WriteLine("  VOUCHER FOR THE USER: CAPTURING THE USERS INFO");
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME:");
            userSurname = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR AGE:");
            userAGe = Convert.ToInt32(Console.ReadLine());

            //Checking for employmenet
            Console.WriteLine("PLEASE WRITE YES IF YOU ARE EMPLOYED ,WRITE NO IF NOT..");
            userEmployment = Console.ReadLine();

            if (userEmployment == "true")
            {

            }

        }
         static void ConfirmData()
        {

        }
        static void DiscountCheck()
        {

        }
        static void ExitProgram()
        {

        }
    }
}

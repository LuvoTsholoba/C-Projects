﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:19 APRIL 2022
//THIS PROGRAM IS ABOUT CALCULATING HOW MANY CARS DO THE USER WANT.

namespace TAXI
{
    internal class Program
    {
        //Global variables
        static string userName,userSurname;
        static int userTaxi;
         static double TAXITOTAL;
         static double INCLUDEDED;

        //PUblic variable
        const  double ONETAXI = 198000.95;
        const double TAX = 1.25;


        static void Main(string[] args)
        {
            //calling out all the methods
            STARTSCREEN();
            GETINFO();
            CALCULATIONS();
            ENDOFPROGRAM();

        }
        static void STARTSCREEN()
        {
            //PRINTIMG OUT THE START SCREEN TO THE BUTYEEonsole.
            Console.WriteLine("++++++++_+++++++_+++++++_++++++_+++++++++++++++++++++");
            Console.WriteLine("/       RSA TOYOTA TAXI SALES PROGRAM /");
            Console.WriteLine("/");
           Console.WriteLine("/PRICE PER TOYOTA TAXI = R198000.95");
            Console.WriteLine("/TAX ON THE NEW TAXI =25%(CARBON TAX INC)");
            Console.WriteLine("/++++++++_+++++++_+++++++_++++++_+++++++++++++++++++++");
            Console.ReadKey();
        }
        static void GETINFO()
        {
            //GETTING REQUIRED INFO ABOUT THE BUYER
            Console.WriteLine("PLEASE ENTER YOUR NAME AND SURNAME:{0} {0}", userName);
            Console.ReadLine();
            Console.WriteLine("THANK YOU :{0}", userName, userSurname);
            Console.ReadLine();
            Console.WriteLine("PLEASE ENTER HOW MANY TOYOTA TAXI YOU LOVE TO PURCHASE");
            userTaxi = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("THANK YOU WE WILL DO CALCULATIONS FOR {1} TAXIS",userTaxi);
            Console.ReadKey();

        }
        static void CALCULATIONS()
        {
            //DPOING CALCULATIONS FOR THE REQUIRED
            TAXITOTAL = userTaxi * ONETAXI;
            INCLUDEDED = TAX + TAXITOTAL;

        }
        static void ENDOFPROGRAM()
        {

        }
    }
}

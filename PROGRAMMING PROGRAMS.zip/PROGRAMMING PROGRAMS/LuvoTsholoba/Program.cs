﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuvoTsholoba
{
    internal class Program

    {
        //Local Variables
        const string PASSWORD = "luvo tsholoba";
        static string userName, userSurname, userPassword;
        static Double userAge;

        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Green;
            Console.WriteLine("++++++++++++++++++++++++++++++++++");
            Console.WriteLine("WELCOME THE SECURITY SYSTEM");
            Console.WriteLine("++++++++++++++++++++++++++++++++++");
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO CAPTEURE YOUR INFORMATION");
            Console.ReadKey();
            LuvoTsholoba();
        }
        static void LuvoTsholoba()
        {
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.Clear();
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("THIS MENU IS TO CAPTURE YOUR INFORMATION");
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER YOUR NAME");
            userName = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME");
            userSurname = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR AGE");
            userAge = Convert.ToInt32(Console.ReadLine());
            if(userAge<=16)
            {
                Console.WriteLine("TOO YOUNG TO KNOW NOR USE THIS SECURITY SYTEM");

                Console.ReadLine();
                EndofProgarm();
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.Black;
                Console.WriteLine("PLEASE PROCEED!!");
                Console.ReadLine();
            }
            Console.WriteLine("PRESS ANY KEY TO ENTER CORRECT PASSWORD below.");
            Console.ReadKey();
            Password();

        }
        static void Password()
        {
            Console.WriteLine("PLEASE ENTER THE CORRECT PASSWORD");
            userPassword = Console.ReadLine();

            if(userPassword==PASSWORD)
            {
                Console.WriteLine("ACCESS GRANTED TO PRINT THE INFO GIVEN");
                Console.ReadKey();
                PRINTOUT();

            }
            else
            {
                Console.WriteLine("SORRY BUT YOU HAVE CHANGED THE PASSWORD OF THIS SYSTEM");
                Console.ReadKey();
                PRINTOUT();
            }

        }
        static void PRINTOUT ()

        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("*******************************************");
            Console.WriteLine("PRINTING OUT THE GIVEN INFORMATION");
            Console.WriteLine("*******************************************");
            Console.WriteLine();
            Console.WriteLine("1.THE USER NAME   :{0}", userName);
            Console.WriteLine("2.THE USER SURNAME:{0}", userSurname);
            Console.WriteLine("3.THE USER AGE:    {0}",userAge);
            Console.WriteLine("4.THE USER PASSWORD:{0}", userPassword);
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO EXIT THE SYSTEM");
            Console.ReadKey();
            theEnd();


        }
        static void EndofProgarm()
        {
            Console.WriteLine("TOO YOUNG BOY ,PLEASE CALL ME ON THIS NUMBER ,0732490979");
            Console.ReadKey();

        }
        static void theEnd()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("THANK YOU FOR USING THE SYSTEM,ENJOY THE REST OF YOUR DAY");
            Console.ReadKey();
        }
    }
}

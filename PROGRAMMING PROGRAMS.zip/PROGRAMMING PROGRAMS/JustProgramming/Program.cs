﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:28 March 2022
//Location:Sila
//Just a basic program ,just playing with codes

namespace JustProgramming
{
    internal class Program
    {
        //Global variables
        static string userName, userSurname, userInput;
        static int age, yourSalary;
       static int userNumber, userWord;

        //Constant variables
        const string CORRECTWORD = " Water";
        const int CORRECTNUMBER = 12;


        static void Main()
        {
            StartScreen();
            MainMenu();
            MAINMENU2();
            WORDGAME();
            NUMBERGAME();
            EndofProgram();
        }
        static void StartScreen()
        {
            Console.WriteLine("----=-=-=-=-==-===-=-=-=---=-=-=-=-=-=-=--=");
            Console.WriteLine(  "WELCOME TO OUR WORD AND NUMBER GAME");
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO GO THROUGH OUR MAIN MENU.ASBONGE");
            Console.WriteLine("----=-=-=-=-==-===-=-=-=---=-=-=-=-=-=-=--=");
            Console.ReadLine();
            Console.ReadKey();
        }
        static void MainMenu()
        {
            //JUST CLEARING THE SCREEN
            Console.Clear();
            //Starting the main menu
            Console.WriteLine("----=-=-=-=-==-===-=-=-=---=-=-=-=-=-=-=--=");
            Console.WriteLine("WELCOME TO THE MAIN MENU OF THE GAME");
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO CONTINUE");
            Console.ReadLine();
            Console.WriteLine("----=-=-=-=-==-===-=-=-=---=-=-=-=-=-=-=--=");
            Console.WriteLine();
            //CLEARING THE SCREEN 
            Console.Clear();
            //USER PROVIDING HIS OR HER DEATILS

            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME:");
            userName = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR AGE:");
            age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("PLEASE ENTER YOUR SALARY");
            yourSalary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Thank YOU MR {0}{1} WE HABVE CAPTURED YOUR INFORMATION.ASBONGE", userName, userSurname);
            Console.ReadKey();
            MAINMENU2();
        }
        static void MAINMENU2()
        {
            //CLEAR EVERYTHING
            Console.Clear();
            //GIVING THE USER OPTIONS TO CHOOSE FROMASE 
            Console.WriteLine("WELCOME MR {0} PLEASE CHOOSE FROM THE FOLLOWING",userName);
            Console.WriteLine("1.FOR WORDGAME");
            Console.WriteLine("2.FOR NUMBERGAME");
            Console.WriteLine("3.FOR EXTING");
            //rEADING THE USERS INPUT
            Console.WriteLine();
            Console.WriteLine("PLEASE CHOOSE FROM 1,2 AND 3");
            Console.ReadLine();
            //inckuding the if state
            if(userInput==)
            {

            }
   
        }
        static void WORDGAME()
        {

        }
        static void NUMBERGAME()
        {

        }
        static void EndofProgram()
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:06 APRIL 2022
//Thsis program is about counting months given to the user


namespace MonthNumber
{
    internal class Program
    {
        static int monthNumber;


        static void Main(string[] args)
        {
            houseKeeping();
            Details();
            EndofProgram();
        }
        static void houseKeeping()
        {
            Console.WriteLine("MONTH OF THE PROGRAM");
            Console.WriteLine();
            Console.WriteLine("PLEASE ENETER THE NUMBER FROM 1 -6");
            monthNumber = Convert.ToInt32(Console.ReadLine());
        }
        static void Details()
        {
            switch (monthNumber)
            {
                case 1:
                    Console.WriteLine("YOUR MONTH IS JANUARY");
                    break;

                case 2:
                    Console.WriteLine("YOUR MONTH IS FEBRUARY");
                    break;

                case 3:
                    Console.WriteLine("YOUR MOTNH IS MARCH ");
                    break;

                case 4:
                    Console.WriteLine("YOUR MONTH IS APRIL");
                    break;

                case 5:
                    Console.WriteLine("YOUR MONTH IS MAY");
                        break;

                case 6:
                    Console.WriteLine("YOUR MONTH IS JUNE.");
                    break;

                default:
                    Console.WriteLine("NUMBER YOU HAVE ENETERED IS INCORRECT.");
                    break;
                    Details();
            }


        }
        static void EndofProgram()
        {
            Console.WriteLine("THANK FOR USING OUR APP");
            Console.ReadKey();

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo tsholoba
//Date:10April2022



namespace Boolen
{
    internal class Program

    {
        static string userName, userSurname, underAGE, perfectage;
        static bool userAge;


        static void Main(string[] args)
        {
            MainMenu();
            EndMenu();
        }
        static void MainMenu()
        {
            Console.WriteLine("PLEASE ENTER YOUR NAME");
            userName = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME");
            userSurname = Console.ReadLine();
            Console.WriteLine("ARE YOU 18 YEARS OF AGE.YES OR NO?");
            Console.ReadLine();
            //INTRODUCING THE BOOLEAN
         

        }
        static void EndMenu()
        {

        }
    }
}

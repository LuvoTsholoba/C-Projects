﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace README
{
    internal class Program
    {
        static void Main()
        {
            double firstNumber, secondNumber;
            string userName;

            Console.WriteLine("Enter your name:");
            userName = Console.ReadLine();
            Console.WriteLine($"Welcome{userName}");
            Console.WriteLine("GIVE YOUR NUMBERS");
            firstNumber = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("GIVE YOUR SECOND NUMBER");
            secondNumber = Convert.ToDouble(Console.ReadLine());
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:23 March 2022

namespace DualIF
{
    internal class Program
    {
        static void Main()
        {
            //Calling out methods 
            HouseKeeping();
            Detail();
            EndOfProgram();
        }
        HouseKeeping()
        {

        }
    }
}
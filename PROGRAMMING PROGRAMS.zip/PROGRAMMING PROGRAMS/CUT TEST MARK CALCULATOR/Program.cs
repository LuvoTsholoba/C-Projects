﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo TSHOLOBA
//DATE:11 APRIL 2022
//THIS PROGRAM CALCULATE THE MARKS OF CUT STUDENTS

namespace CUT_TEST_MARK_CALCULATOR
{
    internal class Program
    {
        //Global variables
        static string userName;
        static double testMark1, testMark2, testMark3, FINALE,FINALEMARK;
        //Constant variables
        const double WEIGHT1 = 35, WEIGHT2 = 50, WEIGHT3 = 15, TOTAL = 100;
        const double WEIGHTDIV = 2.857, WEIGHTDIV2 = 2.000, WEIGHTDIV3 = 6.666;

        static void Main(string[] args)
        {
            HouseKeeping();
            userInput();
            Calculations();
            EndofJob();
        }

        static void HouseKeeping()
        {
            Console.WriteLine("WELCOME TO THE FINAL MARK CALCULATOR, PLEASE ENTER YOUR NAME:");
            userName = Console.ReadLine();
            Console.WriteLine("THANK YOU {0}", userName);
            Console.WriteLine();
        }
        static void userInput()
        {

            //THIS PROGRAM WILL THEN ASK FOR 3 MARKS FROM STUDENTS
            Console.WriteLine("PLEASE ENTER YOUR MARKS 1 (0 TO 100)");
            testMark1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("PLEASE ENTER YOUR MARKS 2 (0 TO 100)");
            testMark2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("PLEASE ENTER YOUR MARKS 3 (0 TO 100)");
            testMark3 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("THANK YOU ,ALL YOUR MARKS {0} ARE CAPTURED IN THE SYSTEM", userName);
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO RECEIVE YOUR FULL MARKS ");
            Console.ReadKey();
        }
        static void Calculations()
        {
            FINALE = TOTAL/ 2.857 + 2.000 + 6.666;
            FINALEMARK = FINALE/ testMark1 + testMark2 + testMark3;
            Console.WriteLine();

        }
        static void EndofJob()
        {
            Console.WriteLine("WECOME {0} TO YOUR MARK REPORT", userName);
            Console.WriteLine();
            Console.WriteLine("---------------------------------------------------------------------------------------");
            Console.WriteLine("MARK NUMBER:            STUDENT RESULTS:       WEIGHT:              WEIGHT DIVISION:");
            Console.WriteLine("----------              ----------------        -----               -----------------");
            Console.WriteLine("MARK 1                   {0}                      {1}               {2}", testMark1, WEIGHT1, WEIGHTDIV);
            Console.WriteLine("MARK 2                   {0}                      {1}               {2}", testMark2, WEIGHT2, WEIGHTDIV2);
            Console.WriteLine("MARK 3                   {0}                      {1}               {2}", testMark3, WEIGHTDIV3, WEIGHTDIV3);
            Console.WriteLine();
            Console.WriteLine("TOTAL MARKS: {0}",FINALEMARK);
            Console.WriteLine("---------------------------------------------------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO EXIT THE PROGRAM");
            Console.ReadKey();



        }
    }
}

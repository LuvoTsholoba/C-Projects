﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:28 MARCH 2022
//sTUDENT NU:222000756
//tHIS PRORAM IS ABOUT MARKING THE MARKS OF STUDENTS


namespace Progress_Mark_System
{
    internal class Program
    {
        //Global variables
        static int PpcMarks, LskMarks, FitMarks, average;
        static string PpcStatus, LskStatus, FitStatus, averageStatus;

        static void Main()
        {
            StartScreen();
            DetailLoop();
            ResultSlip();
            Console.ReadKey();
        }
        static void StartScreen()
        {
            Console.WriteLine("==========================================================");
            Console.WriteLine(" WELCOME TO THE   PROGRESS REPORT    ");
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER YOUR MARKS FOR THE FOLLOWING MODULES");
            Console.WriteLine("LIFE SKILLS");
            Console.WriteLine("FUNDAMENTALS OF INFORMATION TECHNOLOGY");
            Console.WriteLine("PRINCIPLES OF PROGRAMMING");
            Console.WriteLine("==========================================================");
            Console.WriteLine();
            Console.WriteLine();
            //GIVING USER TO ENTER HIS OR HER MARKS
            Console.WriteLine("PLEASE ENTER YOUR PERCENTAGE FOR LIFE SKILLS(LsK)");
            LskMarks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("PLAESE ENTER YOUR PERCENTAGE FOR FUNDAMENTALS OF IT(fit)");
           Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER YOUR PERCENTAGE FOR PRINCPLES OF PROGRAMMING(Ppc)");
            PpcMarks = Convert.ToInt32(Console.ReadLine());

        }
        static void DetailLoop()
        {
            Console.Clear();
            if (LskMarks >= 50)
            {
                //if the marks are true
                LskStatus = "Pass";
            }
            else
            {
                //if the marks are true 
                LskStatus = "FAIL";
            }
            if(PpcMarks>=50)
            {
                //if the marks are correct
                PpcStatus = "PASS";
            }
            else
            {
                PpcStatus = "FAIL";
            }
            if(FitMarks>=50)
            {
                FitStatus = "PASS";
            }
            else
            {
                FitStatus = "FAIL";
            }
            //Calculating the AVERAGE
            average = (LskMarks + PpcMarks + FitMarks);
            if (average <= 59)
            {
                //if is true
                averageStatus = "FAIL";
            }
            else if (average >= 79)
            {
                //if is true
                averageStatus = "DISTINCTION";
            }
            else
            {
                //IS THE MARKS ARE GOOD
                averageStatus = "PASS";
            }

        }
        static void ResultSlip()
        {
            Console.Clear();
            Console.WriteLine("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-");
            Console.WriteLine("                      RESULTS SLIP OF THE STUDENT              ");
            Console.WriteLine();
            Console.WriteLine("SUBJECT                                 STATUS                                  MARKS:");
            Console.WriteLine("------                                   -----                                   ------");
            Console.WriteLine("LIFE SKILLS                               {0}                                      {1}", LskMarks, LskStatus);
            Console.WriteLine("FUNDAMNETALS OF IT                        {0}                                      {1}", FitMarks, FitStatus);
            Console.WriteLine("PROGRAMMING PRINCIPLES                    {0}                                      {1}", PpcMarks, PpcStatus);
            Console.WriteLine();
            Console.WriteLine("COURSE AVERAGE                            {0}                                      {1}", average, averageStatus);
            Console.WriteLine("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-");

        }
    }
}

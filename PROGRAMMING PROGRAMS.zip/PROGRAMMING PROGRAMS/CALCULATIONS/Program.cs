﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CALCULATIONS
{
    internal class Program
    {
        static double answer = 77, nswer2 = 3, USER;
        static void Main(string[] args)
        {
            Console.WriteLine("PLEASE SOVE THIS, 2+1;");
            USER = Convert.ToDouble(Console.ReadLine());
            if(USER==3)
            {
                Console.WriteLine("YOUR ANSWER IS {0}", nswer2);

            }
            else
            {
                Console.WriteLine("YOUR ANSWER IS {0}", answer);
            }
            Console.ReadKey();
        }
    }
}

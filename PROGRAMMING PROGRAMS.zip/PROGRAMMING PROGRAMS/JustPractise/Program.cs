﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmers:Luvo Tsholoba
//Date:15 MARCH 2022


namespace JustPractise
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //lOCAL VARIABLE
            string name, surname;
            int salary;
            Console.WriteLine("Please enter your name");
            name = Console.ReadLine();
            Console.WriteLine("Please enter your surname");
            surname = Console.ReadLine();
            Console.WriteLine("Please eneter your salary");
            salary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("THANK YOU FOR USING LUVO PRODUCTIONS.TAKE CARE");
            Console.ReadKey();
        }
    }
}

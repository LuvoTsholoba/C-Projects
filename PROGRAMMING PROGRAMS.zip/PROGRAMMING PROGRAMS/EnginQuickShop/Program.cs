﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//This PROGRAM IS ABOUT AN ENGIN SHOP

namespace EnginQuickShop
{ 

    internal class Program
    {
        //Global variables 
        static int product1, product2, product3;
        static int constumerInput1;
        static int constumerInput2;
        static int constumerInput3;
        //the totals of each product
        static int totalofProduct1;
        static int totalofProduct2;
        static int totalofProduct3;
        static int totalDue;

        //Constant variables
          const Double  PROUCT1PRICE = 12.50;
          const Double PRODUCT2PRICE = 11.70;
          const double Product3PRICE = 18.10;
        const int VAT = 14;

        static void Main(string[] args)
        {
            StartScreen();
            MainMenu();
            Calculations();
            Slip();

        }
        static void StartScreen()
        {
            Console.WriteLine("***************************************************");
            Console.WriteLine("         ENGIN QUICK SHOP  ");
            Console.WriteLine();
            Console.WriteLine("PRODUCT 1:6 HOT DOGS BUNS @ R11.50");
            Console.WriteLine("PRODUCT 2:HAKE FISH @ R11.70 EACH");
            Console.WriteLine("PRODUCT 3:2LT COKE @ R18.10  EACH");
            Console.WriteLine();
            Console.WriteLine("***************************************************");
            Console.ReadKey();


        }
        static void MainMenu()
        {
            //ASKING FOR COSTUMER INPUT 
            Console.WriteLine("PLEASE ENTER HOW MANY HALF DOZEN HOTDOGS YOU WANT TO PURCHASE.");
            constumerInput1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("PLEASE ENTER HOW MANY HAKE FISH YOU WANT TO PURCHASE");
            constumerInput2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("PLEASE ENTER HOW MANY 2LT COKE YOU WANT TO PURCHASE");
            constumerInput3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("PRESS ANY KEY TO PRINT OUT THE SLIP");
            Console.ReadKey();
            Slip();


        }
        static void Calculations()
        {
            // CALCULATONS OF EACH PRODUCT THE USER PUT
            //TOTALS OF ALL PRODUCTS 
            totalDue = totalofProduct1 + totalofProduct2 + totalofProduct3 / VAT;

            


        }
        static void Slip()
        {
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("                ENGIN QUICK SHOP      ");
            Console.WriteLine("PRODUCT:               CONSTUMER      TOTALPRICE");
            Console.WriteLine("BUNS                      {0}             {0}", totalofProduct1, constumerInput1);
            Console.ReadKey();

        }
        static void EndofProgram()
        {
            Console.ReadKey();

        }
    }
}

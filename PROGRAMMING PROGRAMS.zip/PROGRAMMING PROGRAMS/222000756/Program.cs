﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//PROGRAMMER:L TSHOLOBA
//STUDENT NUMBER:222000756
//Date: 11 April 2022
//THIS PROGRAM IS  A PPC115C PRACTICE ASSIGMENT

namespace _222000756
{
    internal class Program
    {
        //GLOBAL VARIABLES
        static string userName, userSurname, userName2, userName3, userSurname2, userSurname3, userPlace;
        static double userAge, userAge2, userAge3, userNumber, userInput, travelNumber, travelNumber2, travelPrice, travelPrice2, AGEDISCOUNT, TOTALFOR2MEM;
        //CONSTATNT VARIABLES
        const double WESTERNCAPE = 1190, EASTERNCAPE = 650, NORTHCAPE = 420, NORTHWEST = 550, KWAZULUNATAL = 740, GAUTENG = 730, MPUMALANGA = 660, LIMPOPO = 860;
        const double AGE55 = 0.005, AGE65 = 0.006, AGE75 = 0.007, AGE85 = 0.008, AGE95 = 0.009, AGE99 = 0.010, AGE11 = 0.009;
        static int option;
        static void Main(string[] arg)
        { 
            Menu();
        }
        static void Menu()
        {
            Console.WriteLine("WELCOME TO FREE STATE'S INTERPROVINCIAL SHUTTLE SERVICE");
            //This program will allow you to travel interprovincial to all the capital of the provinces with the provided prices per person
            Console.WriteLine();
            Console.WriteLine("*************************************************");
            Console.WriteLine("   THE PRICES ARE AS FOLLOWS PER PERSON:   ");
            Console.WriteLine();
            Console.WriteLine("1.From Free State to Western Cape = R1190");
            Console.WriteLine("2.From Free State to Eastern Cape = R650");
            Console.WriteLine("3.From Free State to North Cape   = R420");
            Console.WriteLine("4.From Free State to North West =   R550");
            Console.WriteLine("5.From Free State to kwaZulu Natal= R740");
            Console.WriteLine("6.From Free State to Gauteng =      R730");
            Console.WriteLine("7.From Free state to Mpumalanga =   R660");
            Console.WriteLine("8.From Free State to Limpopo =      R860");
            Console.WriteLine("*************************************************");

            //will then call the method 
            houseKeeping();

            Console.ReadKey();
        }
        static void houseKeeping()
        {
            Console.WriteLine();
            Console.WriteLine("MAXIMUM OF 2 FAMILY MEMBERS CAN AND MAY TRAVEL TOGETHER AT A TIME");
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER THE AMOUNT OF FAMILY MEMBERS THAT WILL BE TRAVELLING:");
            userInput = Convert.ToInt32(Console.ReadLine());
            //checking if the user enetered the correct number
            if (userInput > 0 && userInput < 3)
            {
            }
            Console.WriteLine("PLEASE ENTER THE OPTION NUMBER OF THE PROVICE YOU WOULD LOVE TO TRAVEL TO :");
            travelNumber = Convert.ToInt32(Console.ReadLine());
            if (travelNumber > 0 && travelNumber < 8)
            {

            }
            else
            {
                termination();
                Console.ReadKey();
            }
      
            Console.WriteLine();
            Console.WriteLine("***********************************************************");
            Console.WriteLine(" DISCOUNT WILL BE AS FOLLOWED PER PERDON:");
            Console.WriteLine();
            Console.WriteLine("ADULTS 55 AND OLDER RECEIVE 5% OFF");
            Console.WriteLine("ADULTS 65 AND OLDER RECEIVE 6% OFF");
            Console.WriteLine("ADULTS 75 AND OLDER RECEIVE 7% OFF");
            Console.WriteLine("ADULTS 85 AND OLDER RECEIVE 8% OFF");
            Console.WriteLine("ADULTS 95 AND OLDER RECEIVE 9% OFF");
            Console.WriteLine("ADULTS OLDER THAN 99 RECEIVE 10% OFF");
            Console.WriteLine("CHILDREN UNDER 11 GETS 9% OFF");
            Console.WriteLine();
            Console.WriteLine("MEMBERS THAT DONT FALL UNDER CATEGORY WILL PAY THE FULL PRICE");
            Console.WriteLine("*********************************************************************");
            Console.ReadKey();
            memberDetails();
        }
        static void priceCheck()
        {
            //THIS METHOD WILL TEHN SAVE THE PRICE THAT THE USER ENTERED
            //CASE STATEMENT
            switch (option)
            {
                case 1:
                    travelNumber = WESTERNCAPE;
                    userPlace = "WESTERNCAPE";
                    break;

            }


        }
        static void memberDetails()
        {
            //introducing the if statement to check the users input
            if (userInput == 2)
            {
                //Calling for a nethod
                secondMember();
            }
            else
            {
                //Calling for a method if the input is 1
                FirstMember();
            }
        }
        static void FirstMember()
        {
            //claering out of screen
            Console.Clear();

            //this will display if the input is 2
            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME");
            userSurname = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR AGE");
            userAge = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            //calling out for a method
            calculationsforMember();
            Console.ReadKey();
        }
        static void secondMember()
        {
            //CLEARING OUT OF A SCREEN
            Console.Clear();

            //this will display if the input is 2
            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName2 = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME");
            userSurname2 = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR AGE");
            userAge2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            //this will display if the input is 2
            Console.WriteLine("YOU WILL NEED TO ENTER INFORMATIN OF THE SECOND PERSON.");
            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName3 = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME");
            userSurname3 = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR AGE");
            userAge3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            //calling out for a method
            calculationsforMembers();
            Console.ReadKey();

        }
        static void calculationsforMember()
        {
            //Clearing out of a screen
            Console.Clear();
            if (userAge >= 55)
            {
            }
            else if (userAge >= 65)
            {

            }
            else if (userAge >= 75)
            {

            }
            else if (userAge >= 85)
            {

            }
            else if (userAge >= 95)
            {

            }
            else if (userAge >= 99)
            {

            }
            else if (userAge <= 11)
            {

            }
            else
            {
                Console.WriteLine("NO DISCOUNT");
            }
            //CALCULATIONS
            AGEDISCOUNT = travelNumber * userAge3;
            travelPrice = AGEDISCOUNT - travelNumber;
            //calling out for method
            EndforMember();

        }
        static void calculationsforMembers()
        {
            //Clearing out of a screen
            Console.Clear();
            if (userAge2 >= 55)
            {
            }
            else if (userAge2 >= 65)
            {

            }
            else if (userAge2 >= 75)
            {

            }
            else if (userAge2 >= 85)
            {

            }
            else if (userAge2 >= 95)
            {

            }
            else if (userAge2 >= 99)
            {

            }
            else if (userAge2 <= 11)
            {

            }
            else
            {
                Console.WriteLine("NO DISCOUNT");
            }

            //Clearing out of a screen
            Console.Clear();
            if (userAge3 >= 55)
            {
            }
            else if (userAge3 >= 65)
            {

            }
            else if (userAge3 >= 75)
            {

            }
            else if (userAge3 >= 85)
            {

            }
            else if (userAge3 >= 95)
            {

            }
            else if (userAge3 >= 99)
            {

            }
            else if (userAge3 <= 11)
            {

            }
            else
            {
                Console.WriteLine("NO DISCOUNT");
            }
            //CALCULATIONS FOR 2 MEMBERS
            AGEDISCOUNT = travelNumber * userAge3;
            travelPrice = AGEDISCOUNT - travelNumber;
            AGEDISCOUNT = travelNumber2 * userAge2;
            travelPrice2 = AGEDISCOUNT - travelNumber;
            TOTALFOR2MEM = travelPrice + travelPrice2;

            //WILL CALL THE METHOD
            EndforMembers();
        }
        static void EndforMember()
        {
            Console.WriteLine("YOUR NAME:       {0}       ", userName);
            Console.WriteLine("YOUR SURNAME:    {0}", userSurname);
            Console.WriteLine("YOUR AGE:        {0}", userAge);
            Console.WriteLine("YOU GOING TO:    {0}", userPlace);
            Console.WriteLine("PERCENTAGE SAVED:{0}", userInput);
            Console.WriteLine("MONEY SAVED:     {0}", AGEDISCOUNT);
            Console.WriteLine("TOTAL = {0}", travelPrice);

            //CALL OUT THE METHOD OF EXITING 
            termination();
            Console.ReadKey();

        }
        static void EndforMembers()
        {
            Console.WriteLine("YOUR NAME:       {0}       ", userName2);
            Console.WriteLine("YOUR SURNAME:    {0}", userSurname2);
            Console.WriteLine("YOUR AGE:        {0}", userAge2);
            Console.WriteLine("YOU GOING TO:    {0}", userPlace);
            Console.WriteLine("PERCENTAGE SAVED:{0}", userInput);
            Console.WriteLine("MONEY SAVED:     {0}", AGEDISCOUNT);
            Console.WriteLine("TOTAL = {0}", TOTALFOR2MEM);
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO PRINT OUT FOR A SECOND MEMBER");
            Console.ReadLine();

            //THIS WILL DISPLAY FOR A SECOND MEMBER
            Console.WriteLine("YOUR NAME:       {0}       ", userName3);
            Console.WriteLine("YOUR SURNAME:    {0}", userSurname3);
            Console.WriteLine("YOUR AGE:        {0}", userAge3);
            Console.WriteLine("YOU GOING TO:    {0}", userPlace);
            Console.WriteLine("PERCENTAGE SAVED:{0}", userInput);
            Console.WriteLine("MONEY SAVED:     {0}", AGEDISCOUNT);
            Console.WriteLine("TOTAL = {0}", TOTALFOR2MEM);
            Console.WriteLine();
            Console.WriteLine("PRESS ANY KEY TO EXIT THE PROGRAM !");
            termination();
            Console.ReadKey();
        }
        static void termination()
        {
            //This method will then exit the program.
            Console.WriteLine("THANK YOU FOR USING OUR PROGRAM.PRESS ANY KEY TO EXIT !");
            Console.ReadKey();
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:07 april 2022
//THIS PROGRAM IS JUST A MESS PLAYING WITH CODES

namespace JUST_A_MESS
{

    internal class Program
    {
        //Global variables
        static string userName, userSurname;
        static int userAge, userPhone, userPASSWORD, userDrink;
        //CONSTANT VARIABLE
        const int PASSWORD = 24627;
        static void Main(string[] args)
        {
            STARTSCREEN();
            MAINMENU();
            MAINMENU2();
            DETAILS();
        }
        static void STARTSCREEN()
        {
            //REQUIRE INFO ABOUT THE USER
            Console.Clear();
            Console.WriteLine("WELCOME TO A MESSED UP PROGRAM!!!!ENJOY.");
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME");
            userSurname = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR AGE");
            userAge = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("PLEASE ENTER YOUR CELL PHONE NUMBER");
            userPhone =Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("PLEASE ENTER THE PASSWORD TO GO THROUGH");
            userPASSWORD = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            //introducing the if statement
            if(userPASSWORD==PASSWORD)
            {
                Console.WriteLine("ACCESS GRANTED....");
                Console.WriteLine("PLEASE PRESS ANY KEY TO THROUGH MAINMENU2");
                MAINMENU();
                Console.ReadKey();
              
            }
            else
            {
                Console.WriteLine("INCORRECT PASSWORD.PLEASE TRY AGAIN");
                Console.WriteLine("PRESS ANY KEY TO TRY AGAIN");
                STARTSCREEN();
                Console.ReadKey();
            }
        }
        static void MAINMENU()
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine();
       
            Console.WriteLine("PLEASE THINK OF  A NUMBER FROM 1-4 TO CHOOSE YOUR DRINK");
            userDrink = Convert.ToInt16(Console.ReadLine());
            switch (userDrink)
            {
                case 1:
                    Console.WriteLine("YOUR DRINK IS A COKE");
                    Console.ReadLine();
                    break;
                case 2:
                    Console.WriteLine("YOUR DRINK IS A FANTA");
                    Console.ReadLine();
                    break;
                case 3:
                    Console.WriteLine("YOUR DRINK IS PEPSI");
                    Console.ReadLine();
                    break;
                case 4:
                    Console.WriteLine("YOUR DRINK IS STONEY");
                    Console.ReadLine();
                    break;
                default:
                    Console.WriteLine("THE NUMBER YOU ENTERED IS INCORRECT.PLEASE TRY AGAIN");
                    MAINMENU();
                    break;
    
            }



        }
        static void MAINMENU2()
        {
            //CLEARING THE SCREEN
            Console.Clear();
            //THIS MENU PRINTS THE INFORMATION THAT IS WRITTEN
            Console.WriteLine("=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=--=-=");
            Console.WriteLine("         PROVIDED INFORMATION");
            Console.WriteLine();
            Console.WriteLine("YOUR NAME            :{0}",userName);
            Console.WriteLine("YOUR SURNAME:         {0}", userSurname);
            Console.WriteLine("YOUR AGE:             {0}", userAge);
            Console.WriteLine("YOUR CONTACT NUMBER:  {0}", userPhone);
            Console.WriteLine("YOUR DRINK:           {0}", userDrink);
            Console.WriteLine("THE REQUIRED PASSWORD;{0}", userPASSWORD);
            Console.WriteLine("=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=--=-=");
            Console.ReadKey();

        }
        static void DETAILS()
        {
            Console.WriteLine();
            Console.WriteLine("THANK YOU FOR USING OUR SYSTEM");
            Console.WriteLine("PRESS ANY KEY TO EXIT.BYE!!!!!!!!!");
            Console.ReadKey();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Progarmmer:Luvo Tsholoba
//Date:19June 2022
//This program is about calculating the cost of a uber taxi
//StudentNo:222000756

namespace Uber_Taxi_Petrol
{
    internal class Program
    {
        //Global variables 
        static double userInput, totalLiters, Total, priceTrip1,Price2, totalPrice;
        //Constant Varibales
        const double TRIP1 = 184.6, TRIP2 = 232.6, PETROLPRICE = 13.40;

        static void Main(string[] args)
        {
            houseKeeping();
            Inputs();
            Calculations();
            travelReport();
        }
        static void houseKeeping()
        {
            Console.WriteLine("            Welcome to the travel petrol Calculator  ");
            Console.WriteLine();
            Console.WriteLine("Travel Plan:Drive from Bloemfontein(Magaung) to Welcome(Matjhabeng) and then to Kimberly(Sol Plaatje)");
            Console.WriteLine();
            Console.WriteLine("The progam will then request how many kilometres you get on a litre with your car.");
            Console.WriteLine();
            Console.ReadKey();  


        }
        static void Inputs()
        {
            //Clear the screen.
            Console.WriteLine();
            Console.WriteLine("Please enter how many litres per kilometre  your car uses .(Normal Rage is 0.068 to 0.3)");
            userInput = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("WE WILL NOW CALCULATE YOUR PETROL PRICE AMOUNT NEEDED FOR TRAVEL .PRESS ANY KEY FOR YOUR REPORT...");
            Console.WriteLine();
            Console.WriteLine("Press any ke to get your report.");
            Console.ReadKey();

        }
        static void Calculations()
        {
            //Calculations 
            totalLiters = userInput / TRIP1;
            Total = userInput / TRIP2;
            Total = userInput * PETROLPRICE;
            Total = userInput * PETROLPRICE;
            totalPrice = Total * totalLiters;
        }
        static void travelReport()
        {
            Console.WriteLine("WELCOMEE TO YOUR TRAVEL REPORT");
            Console.WriteLine("TRIP 1                      DISTANCE                         COST");
            Console.WriteLine("1                             {0}                             {1}", totalLiters, Total);
            Console.WriteLine("2                             {0}                             {1}", totalLiters, Total);
            Console.WriteLine("Total PRICE={0}", totalPrice);
            Console.ReadKey();



        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAMPLE99
{
    
    internal class Program
    {// Global variables
        static string name, surname;
        static int age;
        static double contactNumber;

        static void Main(string[] args)
        {
            Console.WriteLine("WELCOME TO OUR SERVICE");
            Console.WriteLine();

          Console.ReadKey();
            Mainmenu();

        }
        static void Mainmenu()
        {
            Console.Clear();
            Console.WriteLine("Enter your Name");
            name = Console.ReadLine();
            Console.WriteLine("Enter your Surname");
            surname = Console.ReadLine();
            Console.WriteLine("Enter your age");
            age = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter contact number");
            contactNumber = Convert.ToDouble(Console.ReadLine());

            if(age>85)
            {
                Console.WriteLine("CONGRATULATIONS {0} {1}", name, surname);
            }
            else
            {
                Console.WriteLine("INVALID {0} {1}",name,surname);
            }
            Console.ReadKey();
        }
        static void Print()
        {
            Console.Clear();
            Console.WriteLine("Name : {0}", name);
            Console.WriteLine("Surname: {0}", surname);
            Console.WriteLine("Age:{0}", age);
            Console.WriteLine("Contact Number:{0}", contactNumber);

            Console.ReadKey();

            Exit();

        }
        static void Exit()
        {
            Console.Clear();
            Console.WriteLine("THANK YOU {0} ");
            Console.ReadKey();

        }
    }
}

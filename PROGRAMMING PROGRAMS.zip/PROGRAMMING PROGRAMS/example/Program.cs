﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example
{
    internal class Program
    {
        //Global varibales

        static string gender;
        static int age;

        const int AGE = 88;
        static void Main(string[] args)
        {
            HOUSEKEEPING();
        }
        static void HOUSEKEEPING()
        {
            
            Console.WriteLine("MALE OF FEMALE");
            gender = Console.ReadLine();
            Console.WriteLine("ENTER YOUR AGE");
            age = Convert.ToInt16(Console.ReadLine());

            if (age == AGE)
            {
                Console.WriteLine("ACESS GRANTED");
            }
            else
            {
                Console.WriteLine("YOU WRONG");
                HOUSEKEEPING();
            }
            Console.ReadKey();
        }    

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//PROGRAMMER:Luvo TSHOLOBA
//THIS PROGRAMM IS ABOUT PG GLASS THAT REQUIRES THE WIDTH AND LENGHT FORM THE USER

namespace PG_GLASS_PROGRAM
{
    internal class Program
    {
        //Global variables
        static string userName, userSurname;
        static int userPhoneNumber;
        static int lenghthofGlass, widthofGlass;
        //for doing calculations 
        static double Area, totalPrice, totalVat;

        //Constant variablse
        const double VAT = 1.14;

        static void Main(string[] args)
        {
            StartScreen();
            houseKeeping();
            Quote();
            EndofProgram();
        }
         static void StartScreen()
        {
            Console.WriteLine("======================================");
            Console.WriteLine("         PG GLASS QUOTE");
            Console.WriteLine();
            Console.WriteLine("R5 FOR SQUARE CENTIMETER INCLUDING VAT");
            Console.WriteLine();
            Console.ReadKey();

        }
        static void houseKeeping()
        {
            Console.WriteLine("PLEASE ENTER YOUR NAME:");
            userName = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME:");
            userSurname = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR CONTACT NUMBER");
            userPhoneNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER THE LENGTH OF THE GLASS YOU REQUIRE");
            lenghthofGlass = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("PLEASE ENTER THE WIDTH OF GLASS YOU REQUIRE");
            widthofGlass = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("THANK YOU WE HAVE RECEIVED YOUR INFORMATION ");
            Console.WriteLine("YOUR PG GLASS QUOTE WILL BE AS FOLLOWED");
            Console.ReadKey();
            Calculations();

        }
        static void Calculations()
        {
            Area = lenghthofGlass * widthofGlass;
            totalPrice = Area * 5;
            totalPrice = Area * VAT;


        }
        static void Quote()
        {
            Console.WriteLine("=====================================================");
            Console.WriteLine("      PG GLASS QUOTE");
            Console.WriteLine();
            Console.WriteLine("CUSTOMER NAME:           {0}", userName);
            Console.WriteLine("CUSTOMER SURNAME:           {0}", userSurname);
            Console.WriteLine("CUSTOMER CONTACT NUBERS:    {0}", userPhoneNumber);
            Console.WriteLine();
            Console.WriteLine("REQUIRED GLASS LENGTH:      {0}", lenghthofGlass);
            Console.WriteLine("REQUIRED GLASS WIDTH:       {0}", widthofGlass);
            Console.WriteLine("YOUR TOTAL AREA REQUIRED:   {0}", Area);
            Console.WriteLine("TOTAL PRICE (EXCLU VAT):    {0}", totalPrice);
            Console.WriteLine("TOTAL PRICE (INCLU VAT):    {0}", totalVat);
            Console.ReadKey();
            Console.WriteLine("=====================================================");
        }
        static void EndofProgram()
        {
            Console.WriteLine("PRESS ANY KEY TO EXIT THE PROGRAMME");
            Console.ReadKey();
        }

    }
}

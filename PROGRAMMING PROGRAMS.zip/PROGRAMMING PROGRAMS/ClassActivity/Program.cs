﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Date:18 APril 2022
//this program is about grand

namespace ClassActivity
{
    internal class Program
    {
        //Global variables
        static string userName,userSurname;
        const int AWARD = 500;
        static int userkids, userInput, userAge;
        
        static void Main()
        {
            Menu();
            Menu1();
        }
        static void Menu()
        {
            //GIVING THE USER OPTIONS TO CHOOSE FROM
            Console.Clear();
            Console.WriteLine("PLEASE CHOOSE FROM THE FOLLOWING OPTIONS BELOW");
            Console.WriteLine();
            Console.WriteLine("1.FOR GIVING OUT YOUR DETAILS");
            Console.WriteLine("2.FOR PRINTING OUT YOUR DETAILS");
            Console.WriteLine("3.FOR EXITING THE SYSTEM");

            //INTRODUCING TH IF STATEMENT
            if(userInput==1)
            {
                Menu1();
            }
            if (userInput==2)
            {
                Menu2();
                if(userName==null)
                {
                    Console.WriteLine("PLEASE ENTER MENU 1 TO CAPTURE YOUR INFORMATION FIRST");
                    Console.ReadLine();
                    Console.ReadKey();
                    Menu();
                }
            }
            else if(userInput==3)
            {
                Menu3();
            }
            Console.ReadKey();
        }
        static void Menu1()
        {
            Console.Clear();
            Console.WriteLine("PLEASE ENTER YOUR INFORMATION TO BE CAPTURED");
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER YOUR NAME");
            userName = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR SURNAME.");
            userSurname = Console.ReadLine();
            Console.WriteLine("PLEASE ENTER YOUR AGE");
            userAge = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("HOW MANY CHILDREN DO YOU HAVE?");
            userkids = Convert.ToInt32(Console.ReadLine());

            //Checking the user CHILDERN TO GRANT THEM GRAND 
            if(userkids>3)
            {
                Console.WriteLine("YOU HAVE BEEN AWARDED WITH R500 GRAND !!");
                Console.ReadLine();

            }
            else
            {
                Console.WriteLine("YOU DO NOT QUALIFY FOR A R500 GRAND");
                Console.ReadLine();
            }
            Console.ReadKey();
            Menu();

        }
        static void Menu2()
        {
            //PRINTING OUT THE GIVEN DETAILS
            Console.Clear();
            Console.WriteLine(     "************************************");
            Console.WriteLine(           "PRINTING OUT THE USER DETAILS");
            Console.WriteLine("     ************************************");
            Console.WriteLine();
            Console.WriteLine("USER NAME:{0}", userName);
            Console.WriteLine("SURNAME:{0}", userSurname);
            Console.WriteLine("AGE:{0}", userAge);
            Console.WriteLine("CHILDERN:{0}", userkids);
            Console.WriteLine("AWARDED:R{0}",AWARD);
            Console.ReadKey();
            Menu();

        }
        static void Menu3()
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("THANK YOUR FOR USING OUR SYSTEM.PRESS ANY KEY TO EXIT THE SYTEM");
            Console.ReadLine();
            Console.ReadKey();

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:Luvo Tsholoba
//Student no:222000756
//Date:18 March 2022
//Census Program


namespace CensusProgram
{
    internal class Program
    {
        //Global variable
        static string userName, userSurname, userID;
        static int amountofmembers;
        static double userSalary;



        static void Main()
        {
            StartScreen();
            InputUserData();
            CensusReport();
 

        }
        static void StartScreen()
        {
            Console.WriteLine("Welcome to CENSUS program");
            Console.WriteLine();
            Console.WriteLine("Press any key to capture your information");
            Console.ReadKey();
        }
        static void InputUserData()
        {
            //NAME
            Console.Clear();
            Console.WriteLine("Please enter your name");
            userName = Console.ReadLine();

            //SURNAME
            Console.WriteLine("Please enter your surname");
            userName = Console.ReadLine();

            //USERS ID
            Console.WriteLine("Please enter your ID numbers");
            userID = Console.ReadLine();

            //How may members of the family
            Console.WriteLine("Please enter how many people live in your house");
            amountofmembers = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            //USERS SALARY 
            Console.WriteLine("Please enter your less or more salaary per yaear");
            userSalary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.ReadKey();
        }
        static void CensusReport()
        {
            Console.Clear();
            Console.WriteLine("***************************************************************");
            Console.WriteLine("         CENSUS REPORT    ");
            Console.WriteLine("Citizen userName {0}", userName);
            Console.WriteLine("Citizen surname {0}", userSurname);
            Console.WriteLine("Citizen ID no:{0}",userID);
            Console.WriteLine("number of people in the household: {0}", amountofmembers);
            Console.WriteLine("CITIZEN SALARY PER YER: {0}", userSalary);
            Console.WriteLine("***************************************************************");
            Console.ReadKey();
        }




        }
        
    }
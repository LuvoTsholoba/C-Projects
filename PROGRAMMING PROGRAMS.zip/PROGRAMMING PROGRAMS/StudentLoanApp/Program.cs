﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Programmer:L.Tsholoba
//Student no:22200756
//Cell no:0732490979
//Email adress:tsholobajunior@gmail.com

class Program
{
    string name;
    string surname;
    int ID, loan;
    double interest = 1.072; //7,2 in decimals
    int months = 60;
    static void Main()
    {
        WelcomeScreen();
        GetData();
        AbsaQuote();
    }
    static void WelcomeScreen()
    {
        Console.WriteLine("--------------------------------------");
        Console.WriteLine("    ABSA STUDENT LOAN  ");
        Console.WriteLine("   APPLY FOR A LOAN AND GET A QUOTE...");
        Console.WriteLine("      interest is 7,2% ");
        Console.WriteLine("   PAY BACK AFTER 5 YEARS");
        Console.WriteLine("--------------------------------------");
        Console.WriteLine();
        Console.WriteLine("Press any key to apply for a loan");
        Console.ReadKey();
        Console.Clear();
    }
    static void GetData()
    {
        Console.WriteLine("-------------------------------------------");
        Console.WriteLine("       STUDENT LOAN APPLICATION    ");
        Console.WriteLine("Please enter your Student Name");
        Console.ReadLine();
        Console.WriteLine("Please enter your Student Surname");
        Console.ReadLine();
        Console.WriteLine("Please enter your Student ID Numbers ");
        Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Plese enter the amount you like to loan");
        Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("-------------------------------------------");
        Console.WriteLine();
        Console.WriteLine("THANK YOU YOUR DATA HAS BEEN CAPTURED.PRESS ANY KEY TO GET A LOAN QOUTE");
        Console.ReadKey();
        Console.Clear();
    }
    static void AbsaQuote()
    {
        Console.WriteLine("---------------------------------------");
        Console.WriteLine("     ABSA - STUDENT LOAN QUOTE");
        Console.WriteLine("STUDENT : {0}");
        Console.ReadKey();


    }
}

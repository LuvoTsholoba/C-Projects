﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Initals and surname:L.Tsholoba
//Student number:222000756
//Cell NO:0732490979
//Email:tsholobajunior@Gmail.com

namespace MCSA_Program
{
    internal class Program
    {
        //Global variables 
        static int NumberofStudents;
        static string UniversityName;
        static string TotalExludingVat, TotalIncludingVat;

        //Constant Variables
        const double VAT= 1.15, BUNDLECOST = 45.50;

        static void Main()
        {
            StartScreen();
            UniversityInfo();
            Invoice();
            EndofProgram();
        }
        static void StartScreen()
        {
           Console.WriteLine("=============================================");
            Console.WriteLine("       BULK DATA BUNDLES SYSTEM.");
            Console.WriteLine("               MCSA");
            Console.WriteLine();
            Console.WriteLine("         10GB BUNDLE ONCE OFF");
            Console.WriteLine("BULK PRICE @ R45.50 EXLUCDING VAT PER PRICE");
            Console.WriteLine("=============================================");
            Console.WriteLine("         PRESS ANY KEY TO ACTIVATE DATA FOR YOUR STUDENTS ");
            Console.ReadKey();
        }
        static void UniversityInfo()
        {
            //Clearing of the screen
            Console.Clear();
            Console.WriteLine("DATA BULK BUNDLES SYSTEM");
            Console.WriteLine("       MCSA     ");
            Console.WriteLine("CAPTURING THE UNIVERSITY INFO ..");
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER THE UNIVERSITY NAME");
            UniversityName = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("PLEASE ENTER THE NUMBER OF STUDENTS ");
            Console.ReadLine();
            Console.WriteLine();
            Console.ReadKey();
            Invoice();

        }
        static void Invoice()
        {
            //Clear the screen
            Console.Clear();
            Console.WriteLine("DATA BULK BUNDLES SYSTEM");
            Console.WriteLine("       MCSA     ");
            Console.WriteLine("@ R45.50 EXCLUDING VAT PER PRICE");
            Console.WriteLine();
            Console.WriteLine("         INVOICE    ");
            Console.WriteLine();
            Console.WriteLine("UNIVERSITY:{0}", UniversityName);
            Console.WriteLine("NUMBER OF STUDENTS:{0}", NumberofStudents);
            Console.WriteLine("TOTAL OF EXLUDING VAT:{0}", TotalExludingVat);
            Console.WriteLine("TOTAL INCLUDING VAT:{0}:", TotalIncludingVat);
            Console.ReadKey();

        }
        static void EndofProgram()
        {
            Console.Clear();
            Console.WriteLine("THANK YOU FOR USING OUR PROGRAM.HAVE A NICE DAY.");
            Console.WriteLine();
            Console.ReadKey();

        }
       
    }
}

﻿using Microsoft.EntityFrameworkCore;
using S1P2.BL.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S1P2.DAL
{
    // The AnimalContext class inherits from the Entity Framework’s DbContext
    // (Database Context) class for creating, updating, and deleting the(CRUD)
    // Person objects as needed in the database
    public class AnimalContext : DbContext
    {
        // Animal: a collection of all the Animal entities in the database
        public DbSet<Cow> Cows { get; set; }
        public DbSet<Chicken> Chikens { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //
            // Called by the Entity Framework to connect to the database
            //
            // pass a DbContextOptionsBuilder parameter to the OnConfiguring override
            // method and call the UseSqlite options method to specify that it
            // will connect to a SQLite database.A connection string is passed
            // with the details used to connect to the database
            optionsBuilder.UseSqlite($"Data Source=Animals.db");
        }
    }
}
﻿using S1P2.BL.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S1P2.DAL
{
    public abstract class CowProviderBase
    {
        /// <summary>
        /// This method gets the list of all the business objects from the Cow datastore.
        /// It returns the list of business objects
        /// </summary
        public abstract List<Cow> SelectAll();
        
        /// This method gets a single Cow object from the Cow datastore.
        /// It returns 0 to indicate the Cow was loaded from datastore, or
        /// -1 to indicate that no cow was loaded from the datastore (not found).
       ///
        /// <param name="RFID">The ID of the Person to load from the datastore.</param>
        /// <param name="cow">The Person object loaded from the datastore.</param>
        public abstract int SelectCow(string RFID, ref Cow cow);
        /// This method inserts a record in the Person datastore.
        /// It returns 0 to indicate the Person was inserted into datastore, or
        /// /// -1 to indicate the Person was not inserted because a duplicate was found
        ///
        /// <param name="newCow">The Person object to add to the Person datastore.</param>



        public abstract int Insert(Cow newCow);
        /// This method updates a record in the Cow datastore.
        /// It returns 0 to indicate the Person was found and updated successfully, or
        /// -1 to indicate the Person was not updated because the record was not found
        /// </summary>
        

        public abstract int Update(Cow existingCow);
        /// <summary>
        /// This method deletes a record in the Cow datastore.
        /// It returns 0 to indicate the Animal was found and deleted successfully, or
        /// -1 to indicate the Person was not deleted because the record was not found
        /// </summary>
        /// <param name="RFID">The Person ID of the Person to delete in the Person datastore.</param>

        public abstract int Delete(string RFID);
    }
}

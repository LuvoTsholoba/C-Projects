﻿using S1P2.BL.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace S1P2.DAL
{
    public class CowSQLiteProvider : CowProviderBase
    {
        public override int Delete(string RFID)
        {
            //Method Name : int Delete(string RFID)
            //Purpose : Try to delete a row from the Cow datastore
            //Re-use : none
            //Input Parameter : string RFID
            // - the ID of the  Cow to delete in the Cow datastore
            //Output Type : - int
            // 0 : Person found and deleted successfully
            // -1 : Person not deleted because the record was
            // not foun
            Cow cow;
            int rc;

            try
            {
                using (AnimalContext db = new AnimalContext())
                {
                    cow = db.Cows.FirstOrDefault(p => p.RFID.Equals(RFID));
                    if(cow == null)
                    {
                        rc = -1;
                    }
                    else
                    {
                        db.Cows.Remove(cow);
                        db.SaveChanges();
                        rc = 0;
                    }
                }
            }catch(Exception ex)
            {
                throw ex;

            }
            return rc;
        }

        public override int Insert(Cow newCow)
        {
            //Method Name : int Insert(Cow newCow)
            //Purpose : Try to insert a row in the Cow datastore
            //Re-use : none
            //Input Parameter : Cow newCow
            // - The Person object to add to the Cow datastore
            //Output Type : - int
            // 0 : Cow inserted into datastore
            // -1 : Cow not inserted because a duplicate
            // was found
            Cow cow;
            int rc;

            try
            {
                using (AnimalContext db = new AnimalContext())
                {
                    cow = db.Cows.FirstOrDefault(p => p.RFID.Equals(newCow.RFID));
                    if (cow == null)
                    {
                        db.Cows.Add(newCow);
                        db.SaveChanges();
                        rc = 0;
                    }
                    else
                    {
                        rc = -1;
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
                
            }
            return rc;
        }

        public override List<Cow> SelectAll()
        {
            //Method Name : List<Cow> SelectAll()
            //Purpose : Try to get all the Cow objects from the datastore
            //Re-use : none
            //Input Parameter : None
            //Output Type : - List<Cow>
            // - the generic list that will contain the Cow objects loaded
            // from datastore
            List<Cow> list;

            try
            {
                list = new List<Cow>();
              using (AnimalContext db = new AnimalContext())
                {
                    foreach(var item in db.Cows)
                    {
                        list.Add(item);
                    }
                }

            }catch(Exception ex)
            {
                throw ex;
            }

            return list;
            
        }

        public override int SelectCow(string RFID, ref Cow cow)
        {
            //Method Name : int SelectCow(string RFID, ref Cow cow)
            //Purpose : Try to get a single Cow object from the datastore
            //Re-use : none
            //Input Parameter : - string RFID
            // - The RFID of the Animal to load from the datastore
            // - ref Cow cow
            // - The Cow object loaded from the datastore
            //Output Type : - int
            // 0 : Cow loaded from datastore
            // -1 : no Animalmal was loaded from the datastore
            // (not found)
            int rc;

            try
            {
                using (AnimalContext db = new AnimalContext())
                {
                    cow = db.Cows.FirstOrDefault(p => p.RFID.Equals(RFID));

                    if(cow == null)
                    {
                        rc = -1;
                    }
                    else
                    {
                        rc = 0;
                    }
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }
            return rc;
        }

        public override int Update(Cow existingCow)
        {
            //Method Name : int Update(Cow existingCow)
            //Purpose : Try to update a row in the datastore
            //Re-use : none
            //Input Parameter : Cow existingCow
            // - The new Person data for the row in the datastore
            //Output Type : - int
            // 0 : cow found and updated successfully
            // -1 : cow not updated because the record was
            // not found
            Cow cow;
            int rc;

            try
            {
                using (AnimalContext db = new AnimalContext())
                {
                    cow = db.Cows.FirstOrDefault(p => p.RFID.Equals(existingCow.RFID));

                    if (cow == null)
                    {
                        rc = -1;
                    }
                    else
                    {
                        cow.Name = existingCow.Name;
                        cow.Age = existingCow.Age;
                        cow.MilkProductionLitre = existingCow.MilkProductionLitre;
                        cow.BreedType = existingCow.BreedType;
                        db.SaveChanges();

                        rc = 0;
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return rc;
        }
    }
}

﻿using S1P2.BL.Classes;
using S1P2.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S1P2.BL
{
    public class CowBL
    {
        private CowProviderBase providerBase;

        public CowBL(string Provider)
        {
            //Method Name : CowBL(string Provider)
            //Purpose : Overloaded constructor; invoke setupProviderBase to setup
            // data provider
            //Re-use : setupProviderBase()
            //Input Parameter : string Provider
            // - The name of the data provider to use
            //Output Type : None
            /// <summary>
            /// This method gets the list of all the business objects from the Cow datastore.
            /// It returns the list of business objects
            /// </summary>

            setupProviderBase(Provider);
        }

        public List<Cow> SelectAll()
        {
            /// <summary>
            /// This method gets a single Cow object from the Cow datastore.
            /// It returns 0 to indicate the Cow was loaded from the datastore, or
            /// -1 to indicate that no Cow was loaded from the datastore.
            /// </summary>
            /// <param name="RFID">The Person ID of the Cow to load from the datastore.</param>
            /// <param name="cow">The Person object loaded from the datastore.</param>

            return providerBase.SelectAll();
        }

        public int SelectCow(string RFID, ref Cow cow)
        {
            /// <summary>
            /// This method inserts a record in the Cow datastore.
            /// It returns 0 to indicate the Cow was inserted into datastore, or
            /// -1 to indicate the Cow was not inserted because a duplicate was found
            /// </summary>
            /// <param //name="newCow">The Person object to add to the Cow datastore.</param>
            return providerBase.SelectCow(RFID, ref cow);
        }

        public int Insert (Cow existingCow)
        {
            /// This method updates a record in the Cow datastore.
            /// It returns 0 to indicate the Cow was found and updated successfully, or
            /// -1 to indicate the Cow was not updated because the record was not found
            /// </summary>
            /// <param name="existingCow">The new Cow data for the record in the Cow
            return providerBase.Insert(existingCow);
        }

        public int Update (Cow existingCow)
        {
            /// <summary>
            /// This method deletes a record in the Cow datastore.
            /// It returns 0 to indicate the Cow was found and deleted successfully, or
            /// -1 to indicate the Cow was not deleted because the record was not found
            /// </summary>
            /// <param name="RFID">The Cow ID of the Cow to delete in the Cow datastore.</param>
            return providerBase.Update(existingCow);
        }

        public int Delete(string RFID)
        {
            return providerBase.Delete(RFID);
        }//End Method

        private void setupProviderBase(string Provider)
        {
            //Method Name : void setupProviderBase()
            //Purpose : Helper method to select the correct data provider
            //Re-use : None
            //Input Parameter : string Provider
            // - The name of the data provider to use
            //Output Type : None
            providerBase = new CowSQLiteProvider();
        }
    }
}

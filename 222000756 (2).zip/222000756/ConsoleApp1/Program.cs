﻿using System;

using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ConsoleApp1
{
    internal class Program
    {
        static void Main()
        {
          
        }
        static void ShowMe()
        {
            Animal animalArrayList = new Animal();
            animalArrayList.Add(new Cow("Donna"));
            animalCollection.Add(new Chicken("Mary"));

            foreach (Animal arrayList in animalArrayList)
            {
                arrayList.Feed();
                if ((arrayList.GetType() == typeof(Chicken)))
                {
                    ((Chicken)arrayList).LayEgg();
                }
                else
                    if ((arrayList.GetType() == typeof(Cow)))
                {
                    ((Cow)arrayList).Milk();

                }

            }
            Console.ReadKey();


        }


    }
    public class Animal
    {
        public string name;

        public string Name
        {
            get { return name; }
            set { value = name; }
        }
        public Animal()
        {
            name = "The animal has no name.";
        }
        public Animal(string Pname)
        {
            Pname = name;
        }

        public void Feed()
        {
            Console.WriteLine($"{name} has been feed.");
        }
    
    
    }
    public class Cow:Animal
    {
      public void Milk()
        {
            Console.WriteLine($"{name } has been milked.");
        }
        public Cow(string newName):base(newName)
        {

        }
    }
    public class Chicken : Animal
    {
        public void LayEgg()
        {
            Console.WriteLine($"{name} has laid an egg");
        }
        public Chicken(string newName):base(newName)
        {

        }
    }


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonDB1
{
    public class Person
    {
        public string ID { get; set; }
        public int Age { get; set; } // end property
        public string FirstName { get; set; } // end property
        public string LastName { get; set; } // end property


        public Person(string ID, int Age, string FirstName, string LastName)
        {
            this.ID = ID; this.Age = Age;
            this.FirstName = FirstName;
            this.LastName = LastName;
        } // end constructor
        public Person()
        {
        }
        public override string ToString()
        {
            return $"{ID} : {FirstName}  {FirstName} ({Age})";
        }
    }
    
    
  
}

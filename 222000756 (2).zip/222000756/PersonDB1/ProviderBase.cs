﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonDB1
{
    abstract class ProviderBase
    {
        public abstract List<Person> SelectAll();
        public abstract int SelectPerson(string ID, ref Person person);
        public abstract int Insert(Person newPerson);
        public abstract int Delete(string ID);
    }
}

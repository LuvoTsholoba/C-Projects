﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace usingLinq
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string [] names =  { "Alonso", "Zheng", "Smith", "Jones",
"Smythe", "Small", "Ruiz", "Hsieh", "Jorgenson",
"Ilyich", "Singh", "Samba", "Fatimah" };

            var query = from n in names
                        where n.Contains("e")
                        where n.Contains("i")
                        select n;

            Console.WriteLine("Names that contain  with e and i ");

            foreach(var item in query)
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();
        }
    }
}

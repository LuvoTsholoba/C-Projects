﻿using PersonDb2.DAL;
using System;

namespace  PersonDb
{
    internal class Program
    {
        static void Main(string[] args)
        {
            person
        }
    }

}
﻿using Microsoft.EntityFrameworkCore;
using PersonDb2.BusinessLayer.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonDb2.DAL
{
    internal class PersonContext:DbContext
    {
        public DbSet<Person> Persons { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //
            // Called by the Entity Framework to connect to the database
            //
            // pass a DbContextOptionsBuilder parameter to the OnConfiguring override
            // method and call the UseSqlite options method to specify that it
            // will connect to a SQLite database.A connection string is passed
            // with the details used to connect to the database
            object p = optionsBuilder.UseSqlite($"Data Source=Persons.db");
        } // end method
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonDb2.BusinessLayer.Classes
{
    public abstract class ProviderBase
    {
        public abstract List<Person> SelectAll();
        public abstract int SelectPerson(string ID, ref Person person);
        public abstract int Insert(Person newPerson);
        public abstract int Update(Person existingPerson);
        public abstract int Delete(string ID);

    }
}

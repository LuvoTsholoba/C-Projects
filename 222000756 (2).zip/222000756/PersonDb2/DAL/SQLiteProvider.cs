﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonDb2.DAL
{
    internal class SQLiteProvider
    {
    }
}

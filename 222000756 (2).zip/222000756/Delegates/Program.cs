﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Delegates
{
    internal class Program
    {
       


        static void Main(string[] args)
        {
            ArrayList animalArray = new ArrayList();

            Cow c1 = new Cow("Cow1"); Cow c2 = new Cow("Cow2");

            c1.Age = 10;c2.Age = 90;

            if(c1.Age>c2.Age)
            {
                Console.WriteLine("Cow 1 is bigger than cow 2");

            }
            else if(c1.Age<c2.Age)
            {
                Console.WriteLine("Cow 2 is bigger than cow 1");

            }
           

            Console.ReadKey();

        }
    }
    public abstract class Animal
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { value = name; }
        }
        public int Age
        {
            get;set;
        }
        public Animal()
        {
            name = "The animal with no name";

        }
        public Animal(string newName)
        {
            name = newName;
        }
        public void Feed()
        {
            Console.WriteLine($"{name} has been fed");
        }
    }
    public class Cow:Animal
    {
        public void Milk()
        {
            Console.WriteLine($"{Name} has laid an egg");
        }
        public Cow(string newName):base(newName)
        {

        }
    }
    public class Chicken : Animal
    { 
       
        public Chicken(string newName) : base(newName)
        {
            ;
        }
        public void LayEgg()
        {
            Console.WriteLine($"{Name} has laid an egg");


        }



    }





}

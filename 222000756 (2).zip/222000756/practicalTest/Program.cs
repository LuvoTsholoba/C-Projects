﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Generics;

namespace practicalTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Animal> animalCollection = new List<Animal>();
            Cow cow = new Cow("Motshidisi");
            animalCollection.Add(cow);
            animalCollection.Add(new Chicken("Sebala"));
            cow.Age = 13;
            animalCollection[1].Age = 89;

            foreach(Animal animal in animalCollection)
            {
             Console.WriteLine($"New {animal} object added to the generic List ,Name is {animal.Name}");
                animal.feed();
            }


            Console.ReadKey();
        }

       
    }

    public abstract class Animal
    {
        public string name;
        public int age;

        public string Name 
        {
            get { return name; }
            set { name = value; }
        }
        public int Age { get; set; }
        public Animal()
        {
            name = "The animal with no name";
        }
        public Animal(string newName,int newAge)
        {
            Name = newName;
            Age = newAge;
        }
        public void feed()
        {
            Console.WriteLine($"{name} has been feed");
        }
    
    
    
    }
    public class Cow : Animal
    {
        public void Milk()
        {
            Console.WriteLine($"{name} has been milked");
        }
        public Cow(string newName,int newAge):base(newName,newAge)
        {

        }
    }
    public class Chicken:Animal
    { 
        public void LayEggs()
        {
            Console.WriteLine($"{name} has laid some eggs ");
        }
        public Chicken(string newName,int newAge) : base(newName,newAge) { }
    
    
    
    }

}

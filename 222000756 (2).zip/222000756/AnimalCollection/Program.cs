﻿using System;
using System.Collections;
using System.Collections.Generic;

using System.Linq;
using System.Text;

using System.Threading.Tasks;

namespace AnimalCollection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ArrayList animalList = new ArrayList();
            Cow c1 = new Cow("King");
            animalList.Add(c1);
            animalList.Add(new Chicken("Kong"));

            foreach(Animal animal in animalList)
            {
                Console.WriteLine($"The name of my chicken is {animal.name} and my cow is {animal.name} ");
            }

        Console.ReadKey();
        }
    }
}
public abstract  class Animal:IComparable
{
    public string name;
    public int Age;
    

    public int CompareTo(object obj)
    {
        int rc;

        if(obj is Animal)
        {
            rc = this.Age - ((Animal)obj).Age;
        }
        else
        {
            throw new ArgumentException("ewwwww BROTHER");
        }

        return rc;
    }
   

    public int AGE
    {
        get;
        set;
    }

    public string Name
    {
        get { return name; }
        set { value = name; }
    }
    public Animal()
    {
        Name = "The animal with no name";

    }
    public Animal(String newName)
    {
        newName = Name;
    }
    public void Feed()
    {
        Console.WriteLine($"{Name} has been Feed");
    }

}
public class  Cow : Animal
{
    public void Milk()
    {
        Console.WriteLine($"{Name} has been Milked");
    }
    public Cow(String newName) :base(newName)
    {
        newName = name;
    }

}
public class Chicken:Animal
{
    public void LayEggs()
    {
        Console.WriteLine($"{name} has laid an egg");
        
    }
    public Chicken(string newName): base(newName) { }
}



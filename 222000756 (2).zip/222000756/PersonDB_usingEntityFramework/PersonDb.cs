﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonDB_usingEntityFramework
{
    public  class Person
    {
        [Key]public string ID
        {
            get;
            set;
        }
        public string Age
        {
            get;
            set;
        }
        public string FirstName
        {
            get;
            set;
        }
        public string LastName
        {
            get;
            set;
        }
        public Person(string ID,int Age,string FirstName,string LastName)
        {
            this.ID = ID;
            this.Age = Age;
            this.FirstName = FirstName;
            this.LastName = LastName;
        }
        public Person() { }
        public override string ToString()
        {
            return   
        }
    }
}

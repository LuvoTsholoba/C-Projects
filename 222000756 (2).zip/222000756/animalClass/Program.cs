﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace animalClass
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Animal> animals = new List<Animal>();

            Cow c1 = new Cow("Luvo", "Green", 90);
            animals.Add(c1);
            
            foreach(var item in animals)
            {
                if(animals is Cow)
                {
                    ((Cow)animals[0]).Milk();

                    c1.Feed();
                }
            }

            ((Cow)animals[0]).Milk();

            Console.ReadKey();
        }
    }
    public class Animal
    {
        private string name;
        private string color;
        private int age;

        public string Name
        {
            get { return name; }
        }
        public string Color
        {
            get { return color; }
        }
        public int Age
        {
            get { return age; }
        }

        public Animal(string name,string color,int age)
        {
            this.name = name;
            this.color = color;
            this.age = age;
        }
        public string Feed()
        {
            return ($"My name is {name }  , i am {age} years of age and i am {color} in color");
        }
    
    }
    public class Cow:Animal
    {
        private string newName;
        public Cow(string name,string color,int age):base(name,color,age)
        {
            this.newName = Name;

        }
        public void Milk()
        {
            Console.WriteLine($"My name is {Name}");
        }
    }

}

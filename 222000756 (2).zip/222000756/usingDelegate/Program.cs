﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Programmer name:Luvo Tsholoba
//Date of creation:28 July 2024
//Purpose of the program:The purpose of the program is to calculate with the user the method pointer ,the Delagate;
namespace usingDelegate
{
    internal class Program
    {
        public delegate int mathDelegate(int num1, int num2);
        static int Add(int num1, int num2) => num1 + num2;
        static int Subtract(int num1, int num2) => num1 - num2;
        static int Multiply(int num1, int num2) => num1 * num2;
        static int Divide(int num1, int num2) => num1 / num2;
        static void Main(string[] args)
        {
            mathDelegate Calculate;
            Console.WriteLine("----------------------------------");
            Console.WriteLine("       WELCOME TO THE CALCULATOR");
            Console.WriteLine("----------------------------------");
            Console.WriteLine("");
            Console.Write("Enter number 1 :");
            int userInput1 = Convert.ToInt16(Console.ReadLine());
            Console.Write("Enter number 2 :");
            int userInput2 = Convert.ToInt16(Console.ReadLine());
          
            Console.WriteLine("");
            Console.WriteLine("Choose from the following");
            Console.WriteLine("1.ADDITION");
            Console.WriteLine("2.Subraction");
            Console.WriteLine("3.Multiplication");
            Console.WriteLine("4.Division");

            int userOption = Convert.ToInt32(Console.ReadLine());
            Console.ReadLine();

            switch (userOption)
            {
                case 1:
                  

                    Calculate = new mathDelegate(Add);
                    Console.WriteLine($"Answer:{Calculate(userInput1, userInput2)}");
                    break;
                case 2:
                    Calculate = new mathDelegate(Subtract);
                    Console.WriteLine($"Answer:{Calculate(userInput1, userInput2)}");
                    break;
                case 3:
                    Calculate = new mathDelegate(Multiply);
                    Console.WriteLine($"Answer:{Calculate(userInput1, userInput2)}");
                    break;
                case 4:
                    Calculate = new mathDelegate(Divide);
                    Console.WriteLine($"Answer:{Calculate(userInput1, userInput2)}");
                    break;

                default:
                    Console.WriteLine("Invalid Value ");
                    
                    break;

            }
            Console.ReadKey();

        }
    }
}

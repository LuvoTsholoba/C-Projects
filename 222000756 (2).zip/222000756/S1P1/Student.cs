﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S1P1
{
    public class Student : Person, ICloneable
    {
        public string SchoolName { get; set; }
        public Student(string id, string firstName, string lastName, string schoolName) : base(id, firstName, lastName)
        {
            this.SchoolName = schoolName;
        }
        public override string GetInfo()
        {
            return base.GetInfo() + "\nSchool: " + SchoolName;
        }
        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}

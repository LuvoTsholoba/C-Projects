﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S1P1
{
    public class Employee : Person, ICloneable
    {
		public string CompanyName { get; set; }
		public Employee(string id, string firstName, string lastName, string companyName) : base(id, firstName, lastName)
		{
			this.CompanyName = companyName;
		}
		public override string GetInfo()
		{
			return base.GetInfo() + "\nCompany : " + this.CompanyName;
		}
		public object Clone()
		{
			return this.MemberwiseClone();
		}
	}
}

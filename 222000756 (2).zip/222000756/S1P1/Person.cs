﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S1P1
{
    public class Person
    {
		public Address HomeAddress { get; set; }
		public string ID { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public Person(string id, string firstName, string lastName)
		{
			this.ID = id;
			this.FirstName = firstName;
			this.LastName = lastName;
		}
		public virtual string GetInfo()
		{
			return "ID : " + this.ID + "\nName : " + this.FirstName + " " + this.LastName + HomeAddress.ToString();
		}
		public override string ToString()
		{
			return this.GetInfo() + HomeAddress.ToString();
		}
	}
}

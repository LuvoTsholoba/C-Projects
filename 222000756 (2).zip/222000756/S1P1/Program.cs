﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

//Programmer Name : R Mokhobo ; L Tsholoba ; KM Mkhwane ; BS Mathonsi ; TS Shawula ; A Selomane
//Student Numbers : 222000756 ; 220037117 ; 222031562 ; 222004919 ; 222012110 ; 222007184  
//Assignment Nr   : 2024_S1P1 SOD216C
//Purpose         : Student and Employee Maintainance Program. CRUD the Employee and the Student.

namespace S1P1
{
    public class Program
    {
		//Global Variables
        public static List<Employee> empList;
        public static Dictionary<string, Student> studDictionary;
		private static void Main(string[] args)
		{
			//
			//Method Name : void Main(string[] args)
			//Purpose : Main entry into program
			//Re-use : Initialise(); ShowMainMenu();
			// ProcessEmployeeMenu(); ProcessStudentMenu();
			//Input Parameter : string[] args
			// - command line args - not used
			//Output Type : none
			char choice = '0';
			ConsoleKeyInfo cki;


			try
			{
				Initialise();
				Console.WriteLine();
				ShowMainMenu();
				cki = ReadKey();
				WriteLine();
				choice = cki.KeyChar;
				Console.ReadLine();

				Console.WriteLine();

				while (choice != 'x' && choice != 'X')
				{
					switch (choice)
					{
						case '1':
							ProcessEmployeeMenu();
							break;
						case '2':
							ProcessStudentMenu();
							break;
						case 'x':
						case 'X':
							break;
						default:
							Console.WriteLine("Invalid input");
							break;
					} // end switch
					Console.WriteLine();
					ShowMainMenu();
					cki = ReadKey();
					WriteLine();
					choice = cki.KeyChar;
					Console.ReadLine();

				} // end while
			}//end try
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}//end catch


		
		}
		private static void Initialise()
		{
			//
			//Method Name : void Initialise()
			//Purpose : Initialise and instantiate global variables
			//Re-use : none
			//Input Parameter : none
			//Output Type : none
			//
			empList = new List<Employee>();

			studDictionary = new Dictionary<string, Student>();

		}//end method
		public static void ShowMainMenu()
		{
			//
			//Method Name : void ShowMainMenu()
			//Purpose : Display the main menu
			//Re-use : none
			//Input Parameter : none
			//Output Type : none
			//

			Console.WriteLine();
			Console.WriteLine("Please select an option:");
			Console.WriteLine("========================");
			Console.WriteLine("1. Employee Maintenance");
			Console.WriteLine("2. Student Maintenance");
			Console.WriteLine("X. Exit");
			Console.WriteLine();

		}// end method ShowMainMenu()
		public static void ShowEmployeeMaint()
		{
			//
			//Method Name : void ShowEmployeeMaint()
			//Purpose : Display the ShowEmployeeMaint()
			//Re-use : none
			//Input Parameter : none
			//Output Type : none
			//
			Console.WriteLine();
			Console.WriteLine("Employee Maintenance: Please select an option:");
			Console.WriteLine("==============================================");
			Console.WriteLine("1. List Employees");
			Console.WriteLine("2. Add Employee");
			Console.WriteLine("3. Remove Employee");
			Console.WriteLine("4. Update Employee");
			Console.WriteLine("R. Return");
			Console.WriteLine();
		}// end method ShowEmployeeMaint()
		public static void ShowStudentMaint()
		{
			//
			//Method Name : void ShowStudentMaint()
			//Purpose : Display the Student Maintenance menu
			//Re-use : none
			//Input Parameter : none
			//Output Type : none
			//
			Console.WriteLine();
			Console.WriteLine("Student Maintenance: Please select an option:");
			Console.WriteLine("=============================================");
			Console.WriteLine("1. List Students");
			Console.WriteLine("2. Add Student");
			Console.WriteLine("3. Remove Student");
			Console.WriteLine("4. Update Student");
			Console.WriteLine("R. Return");
			Console.WriteLine();

		} // end method ShowStudentMaint()
		public static void ProcessEmployeeMenu()
		{
			//
			//Method Name : void ProcessEmployeeMenu()
			//Purpose : Invoke appropriate method to handle user menu selection
			//Re-use : ShowEmployeeMaint();EmployeeList();EmployeeAdd();EmployeeRemove();
			// EmployeeUpdate()
			//Input Parameter : none
			//Output Type : none
			//
			char choice = '0';
			ConsoleKeyInfo cki;

			ShowEmployeeMaint();
			cki = ReadKey();
			WriteLine();
			choice = cki.KeyChar;
			Console.ReadLine();
			WriteLine();

			switch (choice)
			{
				case '1':
					EmployeeList();
					break;
				case '2':
					EmployeeAdd();
					break;
				case '3':
					EmployeeRemove();
					break;
				case '4':
					EmployeeUpdate();
					break;
				case 'r':
				case 'R':
					break;
				default:
					Console.WriteLine("Invalid input");
					ProcessEmployeeMenu();
					break;
			}//end switch

		}//end method
		 //--------------------------------------------------------------------------------
		 //
		 // Employee related methods
		 //
		 //--------------------------------------------------------------------------------
		public static void EmployeeAdd()
		{
			//
			//Method Name : void EmployeeAdd()
			//Purpose : Get new Employee info and try to add it to list
			//Re-use : ProcessEmployeeMenu(),FindEmployee()
			//Input Parameter : none
			//Output Type : none
			string nameInput1, nameInput2, streetName, cityName, companyName;
			Console.WriteLine("Please supply the following Employee info: ");
			Console.Write("ID : ");
			string _idInput = Console.ReadLine();
			string _idToUpper = _idInput.ToUpper();
			Employee foundemployee = FindEmployee(_idToUpper);
			if (foundemployee != null)
			{
				Console.WriteLine();
				Console.Write(_idToUpper + " NOT added since it is already in the list ");
				Console.WriteLine();
			}
			else
			{
				Console.Write("First Name : ");
				nameInput1 = Console.ReadLine();

				Console.Write("Last Name : ");
				nameInput2 = Console.ReadLine();

				Console.Write("Street : ");
				streetName = Console.ReadLine();

				Console.Write("City : ");
				cityName = Console.ReadLine();

				Console.Write("Company : ");
				companyName = Console.ReadLine();

				if ((!string.IsNullOrEmpty(_idToUpper)) && (!string.IsNullOrEmpty(nameInput1)) && (!string.IsNullOrEmpty(nameInput2)) && (!string.IsNullOrEmpty(companyName)) && (!string.IsNullOrEmpty(streetName)) && (!string.IsNullOrEmpty(cityName)))
				{
					Employee employee = new Employee(_idToUpper, nameInput1, nameInput2, companyName)
					{
						HomeAddress = new Address
						{
							Street = streetName,
							City = cityName
						}

					};
					empList.Add(employee);
					Console.WriteLine();
					Console.WriteLine("{0} added", _idToUpper);
				}
				else
				{
					Console.WriteLine();
					Console.WriteLine("You didn't enter one of the required input for an employee!!! Please check and try again...");
					EmployeeAdd();
				}//end nested if-else
			}//end if-else

			ProcessEmployeeMenu();

		}// end method
		public static void EmployeeList()
		{
			//
			//Method Name : void EmployeeList()
			//Purpose : Display/List the Employee records in the list
			//Re-use : ProcessEmployee
			//Input Parameter : ??
			//Output Type : ??
			if (empList.Count == 0)
			{
				Console.WriteLine();
				Console.WriteLine("No Employee records found");

			}
			else
			{
				for (int counter = 0; counter < empList.Count; counter++)
				{
					Console.WriteLine(empList[counter].GetInfo());
					Console.WriteLine("---------------------------");
				}
			}//end if-else
			ProcessEmployeeMenu();

		} // end method
		public static void EmployeeRemove()
		{
			//
			//Method Name : void EmployeeRemove()
			//Purpose : Try to remove a Employee record from the list
			//Re-use : FindEmployee(), ProcessEmployeeMenu
			//Input Parameter : ??
			//Output Type : ??
			if (empList.Count == 0)
			{
				Console.WriteLine("No Employee records to remove from the list");
			}
			else
			{
				Console.WriteLine("Please enter the employee ID: ");
				string idInput5 = Console.ReadLine();
				string upperId5 = idInput5.ToUpper();
				Employee foundEmp = FindEmployee(upperId5);
				if (foundEmp != null)
				{
					empList.Remove(foundEmp);
					Console.WriteLine();
					Console.WriteLine(upperId5 + " removed from the list");
				}
				else
				{
					Console.WriteLine();
					Console.WriteLine(upperId5 + " Not removed since it is not in the list");
				}//end nested if-else
			}//end if-else

			ProcessEmployeeMenu();


		} // end method
		public static void EmployeeUpdate()
		{

			if (empList.Count == 0)
			{
				Console.WriteLine("No Employee records to update in the list");

			}
			else
			{

				Console.WriteLine("Please enter the employee ID: ");
				string idInput3 = Console.ReadLine();
				string upperId3 = idInput3.ToUpper();
				Employee foundObj = FindEmployee(upperId3);

				if (foundObj != null)
				{
					// Clone the found employee
					Employee clonedEmployee = (Employee)foundObj.Clone();

					//prompt user to enter new first name or press enter not to change
					Console.Write("New first name or press enter not to change: ");
					string nameInput1 = Console.ReadLine();
					//input validation
					if (!string.IsNullOrEmpty(nameInput1))
					{
						clonedEmployee.FirstName = nameInput1;
					}//end single if

					//prompt user to enter new last name or press enter not to change

					Console.Write("New last name or press enter not to change: ");
					string nameInput2 = Console.ReadLine();
					//input validation

					if (!string.IsNullOrEmpty(nameInput2))
					{
						clonedEmployee.LastName = nameInput2;
					}//end single if

					//prompt user to enter new street name or press enter not to change
					Console.Write("New street name or press enter not to change: ");
					string streetName = Console.ReadLine();
					//input validation

					if (!string.IsNullOrEmpty(streetName))
					{
						clonedEmployee.HomeAddress.Street = streetName;
					}//end single if

					//prompt user to enter new city name or press enter not to change
					Console.Write("New city name or press enter not to change: ");
					string cityName = Console.ReadLine();
					//input validation

					if (!string.IsNullOrEmpty(cityName))
					{
						clonedEmployee.HomeAddress.City = cityName;
					}//end single if

					//prompt user to enter new company name or press enter not to change
					Console.Write("New company name or press enter not to change: ");
					string companyName = Console.ReadLine();
					//input validation
					if (!string.IsNullOrEmpty(companyName))
					{
						clonedEmployee.CompanyName = companyName;
					}//end single if

					// Replace the original object in empList with the updated clone
					int index = empList.IndexOf(foundObj);  //find the of returned object
															//assign existing object in position index with an object named clonedEmployee 
					empList[index] = clonedEmployee;
					Console.WriteLine();
					Console.WriteLine(foundObj.ID + " updated");
				}
				else
				{
					Console.WriteLine();
					Console.WriteLine(upperId3 + " Not Updated Since it is not in the list");
				}//end nested if-else

			}//end if-else
			ProcessEmployeeMenu();

		}// end method

		private static Employee FindEmployee(string id)
		{
			//Name              : Employee FindEmployee(string id)
			//Purpose           : Search for an object in the global List<Employee> empList
			//Reuse             : none
			//Input Parameters  : id (string) - the ID of the employee to find
			//Output Type       : Employee - the found employee object, or null if not found

			//intilise int index and use it as a position to find object in empList  
			int index = 0;
			while (index < empList.Count)
			{
				if (empList[index].ID.ToUpper() == id.ToUpper())
				{
					return empList[index];
				}//end single if                                                        
				index++;
			}//end while                                                  
			return null;
		}//end method
		 //--------------------------------------------------------------------------------
		 //
		 // Student menus
		 //
		 //------------------------------------------------------------------------------
		public static void ProcessStudentMenu()
		{
			//
			//Method Name : void ProcessStudentMenu()
			//Purpose : Invoke appropriate method to handle user menu selection
			//Re-use : ShowStudentMaint();StudentList();StudentAdd();StudentRemove();
			// StudentUpdate()
			//Input Parameter : none
			//Output Type : none
			//
			char choice = '0';
			ConsoleKeyInfo cki;

			ShowStudentMaint();
			cki = ReadKey();
			WriteLine();
			choice = cki.KeyChar;
			Console.ReadLine();
			WriteLine();

			switch (choice)
			{
				case '1':
					StudentList();
					break;
				case '2':
					StudentAdd();
					break;
				case '3':
					StudentRemove();
					break;
				case '4':
					StudentUpdate();
					break;
				case 'r':
				case 'R':
					break;
				default:
					Console.WriteLine("Invalid input");
					ProcessStudentMenu();
					break;
			}//end switch


		} // end method
		  //--------------------------------------------------------------------------------
		  //
		  // Student related methods
		  //
		  //--------------------------------------------------------------------------------
		public static void StudentAdd()
		{
			//
			//Method Name : void StudentAdd()
			//Purpose : Get new Student info and try to add it to dictionary
			//Re-use : ProcessStudentMenu()
			//Input Parameter : none
			//Output Type : none
			//
			string nameInput1, nameInput2, streetName, cityName, schoolName;
			Console.WriteLine("Please supply the following Student info: ");

			Console.Write("ID : ");
			string _idInput = Console.ReadLine();
			string upperId = _idInput.ToUpper();
			Student foundstudent = FindStudent(upperId);
			if (foundstudent != null)
			{
				Console.WriteLine();
				Console.Write(upperId + " NOT added since it is already in the list ");
			}
			else
			{
				Console.Write("First Name : ");
				nameInput1 = Console.ReadLine();

				Console.Write("Last Name : ");
				nameInput2 = Console.ReadLine();

				Console.Write("Street : ");
				streetName = Console.ReadLine();

				Console.Write("City : ");
				cityName = Console.ReadLine();

				Console.Write("School Name : ");
				schoolName = Console.ReadLine();

				if ((!string.IsNullOrEmpty(upperId)) && (!string.IsNullOrEmpty(nameInput1)) && (!string.IsNullOrEmpty(nameInput2)) && (!string.IsNullOrEmpty(schoolName)) && (!string.IsNullOrEmpty(streetName)) && (!string.IsNullOrEmpty(cityName)))
				{
					Student student = new Student(upperId, nameInput1, nameInput2, schoolName)
					{
						HomeAddress = new Address
						{
							Street = streetName,
							City = cityName
						}

					};
					studDictionary.Add(upperId, student);
					Console.WriteLine();
					Console.WriteLine("{0} added", upperId);
				}
				else
				{
					Console.WriteLine();
					Console.WriteLine("You didn't enter one of the required input for a student!!! Please check and try again...");
					StudentAdd();
				}//end nested if-else
			}//end if-else
			ProcessStudentMenu();

		} // end method
		public static void StudentList()
		{
			//
			//Method Name : void StudentList()
			//Purpose : Display the Student records in the dictionary
			//Re-use : ProcessStudentMenu()
			//Input Parameter : none
			//Output Type : none
			//
			if (studDictionary.Count == 0)
			{
				Console.WriteLine();
				Console.WriteLine("No Student records found");

			}
			else
			{
				foreach (Student stud in studDictionary.Values)
				{
					Console.WriteLine(stud.GetInfo());
					Console.WriteLine("--------------------------");
				}
			}//end if-else

			ProcessStudentMenu();

		} // end method
		public static void StudentRemove()
		{
			//
			//Method Name : void StudentRemove()
			//Purpose : Try to remove a Student record from the dictionary
			//Re-use : ProcessStudentMenu(), FindStudent()
			//Input Parameter : none
			//Output Type : none
			//
			if (studDictionary.Count == 0)
			{
				Console.WriteLine("No Student records to remove from the list");
			}
			else
			{
				Console.WriteLine("Please enter the employee ID: ");
				string idInput5 = Console.ReadLine();
				string idToUpper = idInput5.ToUpper();
				Student foundStud = FindStudent(idToUpper);
				if (foundStud != null)
				{
					studDictionary.Remove(idToUpper);
					Console.WriteLine();
					Console.WriteLine(idToUpper + " removed from the list");
				}
				else
				{
					Console.WriteLine();
					Console.WriteLine(idToUpper + " Not removed since it is not in the list");
				}//end nested if-else
			}//end if-else

			ProcessStudentMenu();
		} // end method
		public static void StudentUpdate()
		{
			//
			//Method Name : void StudentUpdate()
			//Purpose : Update existing student info
			//Re-use : ProcessStudentMenu(), FindStudent()
			//Input Parameter : none
			//Output Type : none
			//
			if (studDictionary.Count == 0)
			{
				Console.WriteLine("No Student records to update in the list");

			}
			else
			{

				Console.WriteLine("Please enter the student ID: ");
				string idInput3 = Console.ReadLine();
				string uppercaseId = idInput3.ToUpper();
				Student foundObj = FindStudent(uppercaseId);

				if (foundObj != null)
				{
					// Clone the found employee
					Student clonedStudent = (Student)foundObj.Clone();
					Console.WriteLine();

					//prompt user to enter new first name or press enter not to change
					Console.Write("New first name or press enter not to change: ");
					string nameInput1 = Console.ReadLine();
					//input validation
					if (!string.IsNullOrEmpty(nameInput1))
					{
						clonedStudent.FirstName = nameInput1;
					}//end single if

					//prompt user to enter new last name or press enter not to change

					Console.Write("New last name or press enter not to change: ");
					string nameInput2 = Console.ReadLine();
					//input validation

					if (!string.IsNullOrEmpty(nameInput2))
					{
						clonedStudent.LastName = nameInput2;
					}//end single if

					//prompt user to enter new street name or press enter not to change
					Console.Write("New street name or press enter not to change: ");
					string streetName = Console.ReadLine();
					//input validation

					if (!string.IsNullOrEmpty(streetName))
					{
						clonedStudent.HomeAddress.Street = streetName;
					}//end single if

					//prompt user to enter new city name or press enter not to change
					Console.Write("New city name or press enter not to change: ");
					string cityName = Console.ReadLine();
					//input validation

					if (!string.IsNullOrEmpty(cityName))
					{
						clonedStudent.HomeAddress.City = cityName;
					}//end single if

					//prompt user to enter new company name or press enter not to change
					Console.Write("New school name or press enter not to change: ");
					string schoolName = Console.ReadLine();
					//input validation
					if (!string.IsNullOrEmpty(schoolName))
					{
						clonedStudent.SchoolName = schoolName;
					}//end single if

					// Replace the original object in empList with the updated clone
					studDictionary[uppercaseId] = clonedStudent;

					Console.WriteLine();
					Console.WriteLine(uppercaseId + " updated");
				}
				else
				{
					Console.WriteLine();
					Console.WriteLine(uppercaseId + " Not Updated Since it is not in the list");
				}//end nested else

			}//end else
			ProcessStudentMenu();
		} // end method
		private static Student FindStudent(string id)
		{
			//Name              : Student FindStudent(string id)
			//Purpose           : Search for an object in the global studDictionary<string, Student> studDictionary
			//Reuse             : none
			//Input Parameters  : id (string) - the ID of the student to find
			//Output Type       : Student - the found student object, or null if not found

			return studDictionary.ContainsKey(id) ? studDictionary[id] : null;
		}
	}
}
